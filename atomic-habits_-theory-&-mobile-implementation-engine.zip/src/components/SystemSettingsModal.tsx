import React, { useState } from 'react';
import { 
  X, 
  Settings, 
  Volume2, 
  VolumeX, 
  Vibrate, 
  Download, 
  RotateCcw, 
  Smartphone, 
  Check, 
  Wifi, 
  WifiOff, 
  Award,
  Zap
} from 'lucide-react';
import { systemAudio } from '../utils/systemAudio';
import { usePWAInstall } from '../utils/usePWAInstall';
import { calculateHunterRank } from '../utils/rankProgression';

export interface SystemSettings {
  playerName: string;
  soundEnabled: boolean;
  hapticsEnabled: boolean;
  autoPenaltyProtection: boolean;
}

interface SystemSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: SystemSettings;
  onUpdateSettings: (newSettings: SystemSettings) => void;
  totalCompletedCount: number;
  onResetToday: () => void;
  onResetAllData: () => void;
  onExportData: () => void;
  onTestRankUp?: () => void;
}

export const SystemSettingsModal: React.FC<SystemSettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  totalCompletedCount,
  onResetToday,
  onResetAllData,
  onExportData,
  onTestRankUp,
}) => {
  const { isInstallable, isInstalled, isIOS, isOnline, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  if (!isOpen) return null;

  const { currentRank, nextRank, level, remainingQuests, progressPercent } = calculateHunterRank(totalCompletedCount);

  const handleSoundToggle = () => {
    const nextVal = !settings.soundEnabled;
    systemAudio.enabled = nextVal;
    if (nextVal) {
      systemAudio.playSystemChime();
    }
    onUpdateSettings({ ...settings, soundEnabled: nextVal });
  };

  const handleTestSound = () => {
    systemAudio.playSystemChime();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-in fade-in duration-150 text-xs font-mono select-none">
      <div 
        className="w-full max-w-sm system-window rounded-2xl p-3 shadow-[0_0_35px_rgba(6,182,212,0.4)] relative border border-cyan-400 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Corner Accents */}
        <div className="absolute top-0 left-0 w-2.5 h-2.5 border-t-2 border-l-2 border-cyan-400" />
        <div className="absolute top-0 right-0 w-2.5 h-2.5 border-t-2 border-r-2 border-cyan-400" />
        <div className="absolute bottom-0 left-0 w-2.5 h-2.5 border-b-2 border-l-2 border-cyan-400" />
        <div className="absolute bottom-0 right-0 w-2.5 h-2.5 border-b-2 border-r-2 border-cyan-400" />

        {/* Header */}
        <div className="flex items-center justify-between pb-1.5 border-b border-cyan-500/40">
          <div className="flex items-center gap-1.5 text-cyan-400 text-[10px] font-bold tracking-widest uppercase">
            <Settings className="w-3.5 h-3.5 text-cyan-400" />
            <span>[ SYSTEM: REAL-TIME CONFIGURATION ]</span>
          </div>
          <button
            onClick={onClose}
            className="w-5 h-5 rounded flex items-center justify-center text-cyan-400 hover:text-white hover:bg-cyan-950/60 transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Settings Body */}
        <div className="py-2 space-y-2 max-h-[72vh] overflow-y-auto no-scrollbar">
          {/* Automated Rank Labeling Card */}
          <div className="p-2 bg-slate-950 border border-cyan-500/50 rounded-xl space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1">
                <Award className="w-3 h-3 text-cyan-400" />
                <span>// AUTOMATED RANK EVALUATION</span>
              </span>
              <span className={`px-1.5 py-0.2 rounded border text-[8px] font-black uppercase ${currentRank.badgeColor}`}>
                {currentRank.rank}
              </span>
            </div>

            <div className="text-[11px] font-black text-white">
              LVL {level} · "{currentRank.title}"
            </div>

            <p className="text-[8px] text-stone-300 font-sans leading-tight">
              {currentRank.lore}
            </p>

            <div className="mt-1 pt-1 border-t border-cyan-950 space-y-0.5">
              <div className="flex justify-between text-[7px] text-stone-400">
                <span>QUESTS COMPLETED: {totalCompletedCount}</span>
                <span className="text-cyan-300">
                  {nextRank ? `${remainingQuests} to reach ${nextRank.rank}` : 'MAX RANK ATTAINED'}
                </span>
              </div>
              <div className="w-full bg-black rounded-full h-1 overflow-hidden border border-cyan-950">
                <div
                  className="bg-cyan-400 h-full shadow-[0_0_6px_#22d3ee]"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>

              {onTestRankUp && (
                <button
                  type="button"
                  onClick={onTestRankUp}
                  className="w-full mt-1.5 py-1.5 bg-cyan-950/80 hover:bg-cyan-900/90 active:brightness-95 border border-cyan-400/60 rounded-lg text-[8px] font-bold text-cyan-300 uppercase tracking-widest flex items-center justify-center gap-1.5 transition-all shadow-[0_0_8px_rgba(6,182,212,0.3)] cursor-pointer"
                >
                  <Zap className="w-3 h-3 text-cyan-400 animate-pulse" />
                  <span>PREVIEW RANK ADVANCEMENT FX (ANIMATIONS & FANFARE)</span>
                </button>
              )}
            </div>
          </div>

          {/* Player Name */}
          <div className="p-2 bg-slate-950/90 border border-cyan-500/40 rounded-xl space-y-1">
            <label className="text-[9px] font-bold text-cyan-400 uppercase tracking-wider block">
              // PLAYER IDENTIFIER
            </label>
            <input
              type="text"
              value={settings.playerName}
              onChange={(e) => onUpdateSettings({ ...settings, playerName: e.target.value })}
              className="w-full px-2 py-1 bg-black border border-cyan-500/50 rounded text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
            />
          </div>

          {/* Sound & Haptics */}
          <div className="p-2 bg-slate-950/90 border border-cyan-500/40 rounded-xl space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-bold text-cyan-400 uppercase tracking-wider">
                // SYSTEM AUDIO & HAPTICS
              </span>
              <button
                onClick={handleTestSound}
                className="text-[8px] font-bold text-cyan-300 bg-cyan-950/80 border border-cyan-500/40 px-1.5 py-0.2 rounded hover:bg-cyan-900"
              >
                TEST CHIME
              </button>
            </div>

            <div className="flex items-center justify-between text-[9px]">
              <span className="text-stone-300 flex items-center gap-1">
                {settings.soundEnabled ? <Volume2 className="w-3 h-3 text-cyan-400" /> : <VolumeX className="w-3 h-3 text-stone-500" />}
                <span>System Sound FX</span>
              </span>
              <button
                onClick={handleSoundToggle}
                className={`w-7 h-4 rounded-full transition-colors relative ${
                  settings.soundEnabled ? 'bg-cyan-500' : 'bg-stone-800'
                }`}
              >
                <span className={`w-3 h-3 rounded-full bg-slate-950 absolute top-0.5 transition-transform ${
                  settings.soundEnabled ? 'left-3.5' : 'left-0.5'
                }`} />
              </button>
            </div>

            <div className="flex items-center justify-between text-[9px]">
              <span className="text-stone-300 flex items-center gap-1">
                <Vibrate className="w-3 h-3 text-purple-400" />
                <span>Tactile Haptics</span>
              </span>
              <button
                onClick={() => onUpdateSettings({ ...settings, hapticsEnabled: !settings.hapticsEnabled })}
                className={`w-7 h-4 rounded-full transition-colors relative ${
                  settings.hapticsEnabled ? 'bg-cyan-500' : 'bg-stone-800'
                }`}
              >
                <span className={`w-3 h-3 rounded-full bg-slate-950 absolute top-0.5 transition-transform ${
                  settings.hapticsEnabled ? 'left-3.5' : 'left-0.5'
                }`} />
              </button>
            </div>
          </div>

          {/* Offline PWA / APK */}
          <div className="p-2 bg-slate-950/90 border border-cyan-500/40 rounded-xl space-y-1">
            <div className="flex items-center justify-between text-[9px] font-bold text-cyan-400 uppercase tracking-wider">
              <span>// OFFLINE APK / PWA</span>
              <span className={`flex items-center gap-1 text-[8px] ${isOnline ? 'text-emerald-400' : 'text-amber-400'}`}>
                {isOnline ? <Wifi className="w-2.5 h-2.5" /> : <WifiOff className="w-2.5 h-2.5" />}
                {isOnline ? 'ONLINE' : 'OFFLINE'}
              </span>
            </div>

            {isInstalled ? (
              <div className="p-1 bg-emerald-950/50 border border-emerald-500/50 rounded flex items-center gap-1 text-[8px] text-emerald-300 font-bold">
                <Check className="w-2.5 h-2.5 text-emerald-400" />
                <span>STANDALONE APPLICATION INSTALLED</span>
              </div>
            ) : isInstallable ? (
              <button
                onClick={install}
                className="w-full py-1 rounded bg-cyan-500 text-slate-950 font-bold text-[9px] flex items-center justify-center gap-1 shadow-[0_0_8px_#22d3ee]"
              >
                <Smartphone className="w-3 h-3" />
                <span>INSTALL STANDALONE APK / APP NOW</span>
              </button>
            ) : isIOS ? (
              <div>
                <button
                  onClick={() => setShowIOSGuide(true)}
                  className="w-full py-1 rounded bg-cyan-950 border border-cyan-500/50 text-cyan-300 font-bold text-[9px] flex items-center justify-center gap-1"
                >
                  <Smartphone className="w-3 h-3" />
                  <span>INSTALL ON IOS (SAFARI)</span>
                </button>
                {showIOSGuide && (
                  <div className="mt-1 p-1.5 bg-cyan-950/80 rounded border border-cyan-500 text-[8px] text-cyan-200 space-y-0.5">
                    <p>1. Tap the <strong>Share</strong> button in Safari toolbar.</p>
                    <p>2. Select <strong>Add to Home Screen</strong>.</p>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-[8px] text-stone-500 italic">
                Install prompt active in mobile / desktop browsers.
              </div>
            )}
          </div>

          {/* Data Actions */}
          <div className="p-2 bg-slate-950/90 border border-cyan-500/40 rounded-xl space-y-1">
            <span className="text-[9px] font-bold text-cyan-400 uppercase tracking-wider block">
              // DATA MANAGEMENT
            </span>

            <div className="grid grid-cols-2 gap-1">
              <button
                onClick={onExportData}
                className="py-1 px-1.5 rounded bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-[8px] font-bold flex items-center justify-center gap-1 hover:bg-cyan-900"
              >
                <Download className="w-2.5 h-2.5" /> EXPORT SAVE
              </button>
              <button
                onClick={onResetToday}
                className="py-1 px-1.5 rounded bg-amber-950/60 border border-amber-500/40 text-amber-300 text-[8px] font-bold flex items-center justify-center gap-1 hover:bg-amber-900"
                title="Clears today check-ins"
              >
                <RotateCcw className="w-2.5 h-2.5" /> RESET TODAY
              </button>
            </div>

            {!confirmReset ? (
              <button
                onClick={() => setConfirmReset(true)}
                className="w-full py-1 text-[8px] font-bold text-rose-400 hover:text-rose-300 border border-rose-900/60 rounded bg-rose-950/30"
              >
                [ RESET LEVEL TO 0 & E-RANK ]
              </button>
            ) : (
              <div className="p-1.5 bg-rose-950 border border-rose-500/80 rounded flex items-center justify-between text-[8px]">
                <span className="text-rose-200">Confirm Reset Level to 0?</span>
                <div className="flex gap-1">
                  <button
                    onClick={() => setConfirmReset(false)}
                    className="px-1.5 py-0.5 rounded bg-stone-800 text-stone-300"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      onResetAllData();
                      setConfirmReset(false);
                      onClose();
                    }}
                    className="px-1.5 py-0.5 rounded bg-rose-600 text-white font-bold"
                  >
                    Confirm
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="pt-1.5 border-t border-cyan-900/50 flex justify-end">
          <button
            onClick={onClose}
            className="px-3 py-1 bg-cyan-500 text-slate-950 font-black text-[9px] rounded shadow-[0_0_8px_#22d3ee] uppercase"
          >
            [ CLOSE CONFIG ]
          </button>
        </div>
      </div>
    </div>
  );
};
