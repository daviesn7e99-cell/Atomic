import React, { useState } from 'react';
import { 
  ClipboardCheck, 
  Plus, 
  Trash2, 
  Sunrise, 
  Sun, 
  Moon, 
  Layers 
} from 'lucide-react';
import { ScorecardItem, TimeOfDay } from '../types/habits';

interface ScorecardViewProps {
  scorecard: ScorecardItem[];
  onUpdateRating: (id: string, rating: 'positive' | 'neutral' | 'negative') => void;
  onAddItem: (routine: string, timeOfDay: TimeOfDay, rating: 'positive' | 'neutral' | 'negative') => void;
  onDeleteItem: (id: string) => void;
  creatorName?: string;
}

export const ScorecardView: React.FC<ScorecardViewProps> = ({
  scorecard,
  onUpdateRating,
  onAddItem,
  onDeleteItem,
  creatorName = 'Jhondurd3n',
}) => {
  const [activeScorecardRoom, setActiveScorecardRoom] = useState<TimeOfDay>('morning');
  const [newRoutine, setNewRoutine] = useState('');
  const [newTimeOfDay, setNewTimeOfDay] = useState<TimeOfDay>('morning');
  const [newRating, setNewRating] = useState<'positive' | 'neutral' | 'negative'>('neutral');
  const [isAdding, setIsAdding] = useState(false);

  const positiveCount = scorecard.filter((i) => i.rating === 'positive').length;
  const neutralCount = scorecard.filter((i) => i.rating === 'neutral').length;
  const negativeCount = scorecard.filter((i) => i.rating === 'negative').length;

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoutine.trim()) return;
    onAddItem(newRoutine.trim(), newTimeOfDay, newRating);
    setNewRoutine('');
    setIsAdding(false);
  };

  const scorecardRooms: { id: TimeOfDay; label: string; icon: any }[] = [
    { id: 'morning', label: 'Morning Audit', icon: Sunrise },
    { id: 'afternoon', label: 'Midday Audit', icon: Sun },
    { id: 'evening', label: 'Evening Audit', icon: Moon },
  ];

  const filteredScorecard = scorecard.filter((item) => item.timeOfDay === activeScorecardRoom);

  return (
    <div className="h-full flex flex-col justify-between gap-1.5 overflow-hidden text-xs font-mono">
      {/* Header */}
      <div className="system-window rounded-xl p-2 shrink-0 border border-cyan-500/40">
        <div className="flex items-center justify-between pb-1 border-b border-cyan-950">
          <div className="flex items-center gap-1 text-cyan-400 text-[9px] font-bold uppercase tracking-wider">
            <ClipboardCheck className="w-3 h-3 text-cyan-400" />
            <span>[ SYSTEM: POINT-AND-CALL AUDIT ]</span>
          </div>
          <span className="text-[8px] text-cyan-400/80">
            AUDITOR: {creatorName.toUpperCase()}
          </span>
        </div>
        <div className="text-[10px] font-black mt-0.5 text-white">
          BEHAVIORAL DIAGNOSTIC ROSTER
        </div>
        <p className="text-[8px] text-stone-300 font-sans leading-none mt-0.5">
          Rate routines: <strong>[+] BUFF</strong>, <strong>[=] PASSIVE</strong>, <strong>[-] DEBUFF</strong>.
        </p>
      </div>

      {/* Buff / Passive / Debuff Strip */}
      <div className="grid grid-cols-3 gap-1 shrink-0">
        <div className="system-window rounded-lg py-1 px-1.5 text-center border-emerald-500/40 flex items-center justify-between">
          <span className="text-[8px] font-bold text-emerald-400 uppercase">BUFFS (+)</span>
          <span className="text-xs font-black text-emerald-300">{positiveCount}</span>
        </div>
        <div className="system-window rounded-lg py-1 px-1.5 text-center border-cyan-500/40 flex items-center justify-between">
          <span className="text-[8px] font-bold text-cyan-400 uppercase">PASSIVES (=)</span>
          <span className="text-xs font-black text-cyan-300">{neutralCount}</span>
        </div>
        <div className="system-alert-window rounded-lg py-1 px-1.5 text-center border-rose-500/40 flex items-center justify-between">
          <span className="text-[8px] font-bold text-rose-400 uppercase">DEBUFFS (-)</span>
          <span className="text-xs font-black text-rose-300">{negativeCount}</span>
        </div>
      </div>

      {/* Room Category Tabs */}
      <div className="grid grid-cols-3 gap-1 p-0.5 system-window rounded-lg shrink-0">
        {scorecardRooms.map((room) => {
          const Icon = room.icon;
          const isSelected = activeScorecardRoom === room.id;
          const count = scorecard.filter((i) => i.timeOfDay === room.id).length;

          return (
            <button
              key={room.id}
              onClick={() => setActiveScorecardRoom(room.id)}
              className={`py-1 px-1 rounded text-[8px] font-bold flex items-center justify-center gap-1 transition-all ${
                isSelected
                  ? 'bg-cyan-500 text-slate-950 shadow-[0_0_8px_#22d3ee]'
                  : 'text-stone-400 hover:text-cyan-300'
              }`}
            >
              <Icon className="w-2.5 h-2.5" />
              <span>{room.label.split(' ')[0]}</span>
              <span className="text-[7px] opacity-75">({count})</span>
            </button>
          );
        })}
      </div>

      {/* Register Action & Add Form */}
      <div className="flex items-center justify-between px-1 shrink-0 text-[8px] text-cyan-400/80">
        <span>// {scorecardRooms.find((r) => r.id === activeScorecardRoom)?.label}</span>
        <button
          onClick={() => setIsAdding(!isAdding)}
          className="text-cyan-400 font-bold flex items-center gap-1 hover:underline"
        >
          <Plus className="w-2.5 h-2.5" />
          <span>[ REGISTER ROUTINE ]</span>
        </button>
      </div>

      {isAdding && (
        <form onSubmit={handleAdd} className="p-2 system-window rounded-lg space-y-1.5 text-[9px] border border-cyan-400 shrink-0">
          <input
            type="text"
            placeholder="e.g. Check phone immediately upon waking"
            value={newRoutine}
            onChange={(e) => setNewRoutine(e.target.value)}
            className="w-full px-2 py-1 text-[9px] bg-slate-950 border border-cyan-500/50 rounded text-white focus:outline-none focus:border-cyan-400 font-sans"
            autoFocus
          />
          <div className="flex items-center justify-between gap-1">
            <select
              value={newRating}
              onChange={(e) => setNewRating(e.target.value as any)}
              className="px-1.5 py-0.5 text-[8px] bg-slate-950 border border-cyan-500/50 rounded text-white"
            >
              <option value="positive">Buff (+)</option>
              <option value="neutral">Passive (=)</option>
              <option value="negative">Debuff (-)</option>
            </select>
            <div className="flex gap-1">
              <button
                type="button"
                onClick={() => setIsAdding(false)}
                className="px-2 py-0.5 text-[8px] text-stone-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-2.5 py-0.5 text-[8px] font-bold bg-cyan-500 text-slate-950 rounded"
              >
                Save
              </button>
            </div>
          </div>
        </form>
      )}

      {/* Routine list (Fits without scrolling) */}
      <div className="flex-1 min-h-0 system-window rounded-xl p-1.5 divide-y divide-cyan-950 overflow-y-auto no-scrollbar">
        {filteredScorecard.map((item) => (
          <div
            key={item.id}
            className="py-1 px-1 flex items-center justify-between gap-1.5 hover:bg-cyan-950/20 rounded transition-colors"
          >
            <div className="flex-1 min-w-0 pr-1">
              <span className="text-[10px] font-semibold text-white block truncate font-sans">
                {item.routine}
              </span>
              {item.note && (
                <span className="text-[7px] text-cyan-400/60 block truncate">
                  {item.note}
                </span>
              )}
            </div>

            {/* 3-Way Segmented Rating Switch */}
            <div className="flex items-center gap-0.5 bg-slate-950 p-0.5 rounded border border-cyan-950 shrink-0">
              <button
                onClick={() => onUpdateRating(item.id, 'positive')}
                className={`min-w-[22px] min-h-[22px] h-5.5 w-5.5 rounded text-[9px] font-black flex items-center justify-center transition-all ${
                  item.rating === 'positive'
                    ? 'bg-emerald-500 text-slate-950 shadow-[0_0_6px_#34d399]'
                    : 'text-stone-500 hover:text-emerald-400'
                }`}
                title="Mark as Buff"
              >
                +
              </button>
              <button
                onClick={() => onUpdateRating(item.id, 'neutral')}
                className={`min-w-[22px] min-h-[22px] h-5.5 w-5.5 rounded text-[9px] font-black flex items-center justify-center transition-all ${
                  item.rating === 'neutral'
                    ? 'bg-cyan-500 text-slate-950 shadow-[0_0_6px_#22d3ee]'
                    : 'text-stone-500 hover:text-cyan-400'
                }`}
                title="Mark as Passive"
              >
                =
              </button>
              <button
                onClick={() => onUpdateRating(item.id, 'negative')}
                className={`min-w-[22px] min-h-[22px] h-5.5 w-5.5 rounded text-[9px] font-black flex items-center justify-center transition-all ${
                  item.rating === 'negative'
                    ? 'bg-rose-500 text-slate-950 shadow-[0_0_6px_#f43f5e]'
                    : 'text-stone-500 hover:text-rose-400'
                }`}
                title="Mark as Debuff"
              >
                -
              </button>
            </div>

            <button
              onClick={() => onDeleteItem(item.id)}
              className="p-1 text-stone-500 hover:text-rose-400 transition-colors"
              title="Delete routine"
            >
              <Trash2 className="w-2.5 h-2.5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
