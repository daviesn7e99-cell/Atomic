import React, { useState } from 'react';
import { 
  Check, 
  Clock, 
  Plus, 
  AlertTriangle,
  Headphones,
  Zap,
  Sword,
  Brain,
  Eye,
  Activity,
  Layers,
  Award
} from 'lucide-react';
import { Habit, HabitCategory } from '../types/habits';
import { calculateHunterRank } from '../utils/rankProgression';
import { HabitCircularCheckbox } from './HabitCircularCheckbox';
import { DailyGoalCircularRing } from './DailyGoalCircularRing';

interface TodayHabitsViewProps {
  habits: Habit[];
  selectedDate: string;
  onSelectDate: (date: string) => void;
  onToggleHabit: (habitId: string, date: string) => void;
  onOpenTwoMinuteModal: (habit: Habit) => void;
  onOpenNewHabitModal: () => void;
  creatorName?: string;
}

export const TodayHabitsView: React.FC<TodayHabitsViewProps> = ({
  habits,
  selectedDate,
  onSelectDate,
  onToggleHabit,
  onOpenTwoMinuteModal,
  onOpenNewHabitModal,
  creatorName = 'Jhondurd3n',
}) => {
  const [activeRoom, setActiveRoom] = useState<HabitCategory | 'all'>('health'); // default to a category room so it's compact!

  // Compute 7 days date strip
  const getDaysArray = () => {
    const arr = [];
    const today = new Date();
    for (let i = -3; i <= 3; i++) {
      const d = new Date(today);
      d.setDate(today.getDate() + i);
      const iso = d.toISOString().split('T')[0];
      const dayName = d.toLocaleDateString('en-US', { weekday: 'narrow' });
      const dayNum = d.getDate();
      arr.push({ iso, dayName, dayNum, isToday: i === 0 });
    }
    return arr;
  };

  const days = getDaysArray();

  // Total completed quests across all time (for automated Hunter Rank)
  const totalCompletedCount = habits.reduce(
    (sum, h) => sum + h.completedDates.length,
    0
  );

  const { currentRank, nextRank, progressPercent, remainingQuests, level } = calculateHunterRank(totalCompletedCount);

  // Completed on selected date
  const completedTodayCount = habits.filter((h) =>
    h.completedDates.includes(selectedDate)
  ).length;
  const totalHabitsCount = habits.length;
  const completionPercentage = totalHabitsCount > 0 ? Math.round((completedTodayCount / totalHabitsCount) * 100) : 0;

  // Never Miss Twice Detection
  const yesterdayDate = (() => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() - 1);
    return d.toISOString().split('T')[0];
  })();

  const habitsNeedingProtection = habits.filter(
    (h) => !h.completedDates.includes(yesterdayDate) && !h.completedDates.includes(selectedDate)
  );

  const categoryRooms: { id: HabitCategory | 'all'; label: string; code: string; icon: any }[] = [
    { id: 'health', label: 'Vitality', code: 'VIT', icon: Activity },
    { id: 'mind', label: 'Sense', code: 'SEN', icon: Eye },
    { id: 'craft', label: 'Intel', code: 'INT', icon: Brain },
    { id: 'focus', label: 'Strength', code: 'STR', icon: Sword },
    { id: 'all', label: 'All', code: 'ALL', icon: Layers },
  ];

  const displayedHabits = activeRoom === 'all'
    ? habits
    : habits.filter((h) => h.category === activeRoom);

  return (
    <div className="h-full flex flex-col justify-between gap-1.5 overflow-hidden text-xs font-mono">
      {/* 1. Automated Solo Leveling Status Window: Evaluates where Rank you are now */}
      <div className="system-window rounded-xl p-2 shrink-0 border border-cyan-500/40">
        <div className="flex items-center justify-between pb-1 border-b border-cyan-900/60">
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_6px_#22d3ee]" />
            <span className="text-[9px] font-black text-cyan-400 tracking-wider">
              [ PLAYER STATUS: {creatorName.toUpperCase()} ]
            </span>
          </div>
          {/* Automated Current Rank Badge */}
          <div className={`px-1.5 py-0.2 rounded border font-black text-[8px] tracking-wider uppercase ${currentRank.badgeColor}`}>
            {currentRank.rank}
          </div>
        </div>

        {/* Dynamic Title & EXP Bar */}
        <div className="mt-1.5 grid grid-cols-12 gap-2 items-center">
          <div className="col-span-7">
            <div className="flex items-baseline gap-1 text-[11px] font-black text-white leading-tight truncate">
              <span>LVL {level}</span>
              <span className={`text-[9px] font-bold ${currentRank.textColor} truncate`}>
                "{currentRank.title}"
              </span>
            </div>

            {/* Automated EXP Progress to Next Rank */}
            <div className="mt-1 space-y-0.5">
              <div className="flex justify-between text-[7px] text-stone-400 leading-none">
                <span>RANK EXP: {totalCompletedCount} Qs</span>
                <span className="text-cyan-400">
                  {nextRank ? `${remainingQuests} Qs to ${nextRank.rank}` : 'MAX RANK'}
                </span>
              </div>
              <div className="w-full bg-slate-950 rounded-full h-1 overflow-hidden border border-cyan-950">
                <div
                  className="bg-gradient-to-r from-cyan-500 to-blue-500 h-full shadow-[0_0_6px_#22d3ee] transition-all duration-300"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>
          </div>

          {/* Quick HP & Daily Goal Circular Progress Ring */}
          <div className="col-span-5 flex items-center justify-end gap-2 text-[8px]">
            <div className="flex-1 space-y-1">
              <div>
                <div className="flex justify-between text-stone-400 leading-none">
                  <span>HP</span>
                  <span className="text-emerald-400">100%</span>
                </div>
                <div className="w-full bg-slate-950 rounded-full h-1 overflow-hidden border border-emerald-950">
                  <div className="bg-emerald-400 h-full shadow-[0_0_4px_#34d399]" style={{ width: '100%' }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-stone-400 leading-none">
                  <span className="truncate">DAILY GOAL</span>
                  <span className="text-cyan-400 font-bold">{completionPercentage}%</span>
                </div>
                <div className="w-full bg-slate-950 rounded-full h-1 overflow-hidden border border-cyan-950">
                  <div 
                    className="bg-cyan-400 h-full shadow-[0_0_4px_#22d3ee] transition-all duration-300" 
                    style={{ width: `${completionPercentage}%` }} 
                  />
                </div>
              </div>
            </div>

            <DailyGoalCircularRing 
              completedCount={completedTodayCount}
              totalCount={totalHabitsCount}
              size={36}
            />
          </div>
        </div>
      </div>

      {/* 2. Compact Horizontal Date Strip (h-7) */}
      <div className="system-window rounded-lg p-1 shrink-0">
        <div className="flex items-center justify-between gap-1">
          {days.map((item) => {
            const isSelected = item.iso === selectedDate;
            const completedOnDay = habits.filter((h) =>
              h.completedDates.includes(item.iso)
            ).length;

            return (
              <button
                key={item.iso}
                onClick={() => onSelectDate(item.iso)}
                className={`flex-1 py-0.5 rounded flex flex-col items-center justify-center transition-all ${
                  isSelected
                    ? 'bg-cyan-500 text-slate-950 font-black shadow-[0_0_8px_#22d3ee]'
                    : 'text-stone-400 hover:text-cyan-300'
                }`}
              >
                <span className="text-[7px] font-bold uppercase leading-none">{item.dayName}</span>
                <span className="text-[10px] font-mono font-bold leading-tight">{item.dayNum}</span>
                <span className={`w-1 h-1 rounded-full ${
                  isSelected ? 'bg-slate-950' : completedOnDay > 0 ? 'bg-cyan-400' : 'bg-transparent'
                }`} />
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. Never Miss Twice / Penalty Alert Banner (Only if pending) */}
      {habitsNeedingProtection.length > 0 && (
        <div className="system-alert-window rounded-lg px-2 py-1 flex items-center justify-between border border-rose-500/60 shrink-0">
          <div className="flex items-center gap-1.5 text-[8px] text-rose-300">
            <AlertTriangle className="w-3 h-3 text-rose-400 shrink-0" />
            <span className="truncate">
              <strong>PENALTY WARNING:</strong> {habitsNeedingProtection.length} missed yesterday. Complete today to cancel!
            </span>
          </div>
          <span className="text-[7px] font-bold bg-rose-950 border border-rose-500/50 text-rose-400 px-1 py-0.2 rounded">
            NEVER MISS TWICE
          </span>
        </div>
      )}

      {/* 4. Stat Category Rooms Switcher (Zero-Scroll navigation) */}
      <div className="flex items-center gap-1 shrink-0 overflow-x-auto no-scrollbar">
        {categoryRooms.map((room) => {
          const Icon = room.icon;
          const isSelected = activeRoom === room.id;
          const count = room.id === 'all'
            ? habits.length
            : habits.filter((h) => h.category === room.id).length;

          return (
            <button
              key={room.id}
              onClick={() => setActiveRoom(room.id)}
              className={`flex-1 min-h-[26px] px-1 py-0.5 rounded text-[8px] font-mono font-bold flex items-center justify-center gap-1 transition-all border ${
                isSelected
                  ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-[0_0_8px_#22d3ee]'
                  : 'bg-slate-950/80 border-cyan-900/50 text-stone-400 hover:text-cyan-300'
              }`}
            >
              <Icon className="w-2.5 h-2.5" />
              <span>{room.code}</span>
              <span className={`px-0.5 rounded text-[7px] ${isSelected ? 'bg-slate-900 text-cyan-300' : 'bg-black text-stone-400'}`}>
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* 5. Habit Cards inside the Selected Room (Fits exactly in remaining viewport) */}
      <div className="flex-1 min-h-0 overflow-y-auto no-scrollbar space-y-1.5">
        {displayedHabits.map((habit) => {
          const isDone = habit.completedDates.includes(selectedDate);
          const isProtected = habitsNeedingProtection.some((h) => h.id === habit.id);

          return (
            <div
              key={habit.id}
              className={`system-window rounded-lg p-2 transition-all relative border ${
                isDone
                  ? 'border-cyan-900/40 bg-slate-950/60 opacity-75'
                  : 'border-cyan-500/50 hover:border-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.1)]'
              }`}
            >
              {/* Cue trigger header */}
              <div className="flex items-center justify-between text-[8px] text-cyan-400/70 pb-0.5 border-b border-cyan-950">
                <span className="truncate max-w-[220px]">
                  <strong className="text-cyan-300">TRIGGER:</strong> {habit.anchorHabit}
                </span>
                <span className="text-[7px] text-stone-500 uppercase">
                  {habit.timeOfDay}
                </span>
              </div>

              {/* Main content row */}
              <div className="flex items-center justify-between gap-2 pt-1">
                {/* Circular Progress Ring Checkbox */}
                <HabitCircularCheckbox
                  isDone={isDone}
                  onToggle={() => onToggleHabit(habit.id, selectedDate)}
                  title={habit.title}
                  size={36}
                />

                {/* Details */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1">
                    <h4 className={`text-[11px] font-bold font-sans truncate leading-none ${
                      isDone ? 'line-through text-stone-500' : 'text-white'
                    }`}>
                      {habit.title}
                    </h4>
                    {isProtected && !isDone && (
                      <span className="text-[7px] font-bold text-rose-300 bg-rose-950 border border-rose-500/50 px-1 rounded shrink-0">
                        PENALTY RISK
                      </span>
                    )}
                  </div>

                  <p className="text-[8px] text-cyan-400/80 truncate mt-0.5 font-sans italic">
                    "{habit.identityStatement}"
                  </p>

                  {habit.temptationBundle && (
                    <div className="flex items-center gap-1 text-[8px] text-purple-300 mt-0.5 truncate font-sans">
                      <Headphones className="w-2.5 h-2.5 text-purple-400 shrink-0" />
                      <span className="truncate">Reward: {habit.temptationBundle}</span>
                    </div>
                  )}
                </div>

                {/* 2-Min Gateway Starter */}
                {!isDone && (
                  <button
                    onClick={() => onOpenTwoMinuteModal(habit)}
                    className="min-h-[28px] px-1.5 py-0.5 rounded bg-cyan-950/80 border border-cyan-400 text-cyan-300 text-[8px] font-bold flex items-center gap-1 shrink-0 hover:bg-cyan-900 transition-colors shadow-[0_0_6px_rgba(6,182,212,0.2)]"
                    title="2-Minute Gateway Ritual"
                  >
                    <Clock className="w-2.5 h-2.5 text-cyan-400" />
                    <span>2m BURST</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}

        {displayedHabits.length === 0 && (
          <div className="py-4 text-center text-[9px] text-cyan-400/60 system-window rounded-lg">
            NO QUESTS IN THIS ROOM.
          </div>
        )}
      </div>

      {/* 6. Register New Quest Compact Bar */}
      <div className="pt-0.5 shrink-0">
        <button
          onClick={onOpenNewHabitModal}
          className="w-full h-8 rounded-lg bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-bold text-[9px] flex items-center justify-center gap-1 shadow-[0_0_10px_rgba(6,182,212,0.3)] hover:brightness-110 active:brightness-95 transition-all uppercase tracking-wider"
        >
          <Plus className="w-3 h-3" />
          <span>[ REGISTER DAILY QUEST ]</span>
        </button>
      </div>
    </div>
  );
};
