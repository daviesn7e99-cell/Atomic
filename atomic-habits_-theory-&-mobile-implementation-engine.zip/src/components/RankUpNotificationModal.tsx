import React, { useEffect } from 'react';
import { Sparkles, Award, Zap, ChevronRight, Check, ShieldAlert } from 'lucide-react';
import { HunterRankInfo } from '../utils/rankProgression';
import { systemAudio } from '../utils/systemAudio';

interface RankUpNotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  newRank: HunterRankInfo | null;
  previousRankTitle?: string;
  level: number;
}

export const RankUpNotificationModal: React.FC<RankUpNotificationModalProps> = ({
  isOpen,
  onClose,
  newRank,
  previousRankTitle,
  level,
}) => {
  useEffect(() => {
    if (isOpen && newRank) {
      systemAudio.playRankUpFanfare();
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        try {
          navigator.vibrate([40, 30, 60, 30, 90]);
        } catch {
          // ignore
        }
      }
    }
  }, [isOpen, newRank]);

  if (!isOpen || !newRank) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 select-none font-mono overflow-hidden">
      {/* 1. Full-screen Hologram Flash Overlay */}
      <div 
        key={`flash-${newRank.rank}-${Date.now()}`}
        className="absolute inset-0 z-0 animate-hologram-flash pointer-events-none"
      />

      {/* 2. Darkened backdrop behind the modal window */}
      <div 
        className="absolute inset-0 bg-black/85 backdrop-blur-md transition-opacity duration-300" 
        onClick={onClose}
      />

      {/* 3. Horizontal High-Energy Flare Sweep Burst */}
      <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-2.5 bg-gradient-to-r from-transparent via-cyan-300 to-transparent shadow-[0_0_40px_#38bdf8] animate-flare-sweep pointer-events-none z-10" />

      {/* 4. Main Holographic System Window - rigidly anchored */}
      <div 
        className="w-full max-w-sm system-window rounded-2xl p-4 shadow-[0_0_50px_rgba(6,182,212,0.8)] relative border-2 border-cyan-400 overflow-hidden text-center z-20"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Rapid Vertical Cyber Scanline Sweep */}
        <div className="absolute inset-x-0 top-0 h-10 bg-gradient-to-b from-cyan-400/20 via-cyan-400/10 to-transparent pointer-events-none animate-scanline" />

        {/* Glowing corner bracket accents */}
        <div className="absolute top-0 left-0 w-3.5 h-3.5 border-t-2 border-l-2 border-cyan-300 shadow-[0_0_8px_#38bdf8]" />
        <div className="absolute top-0 right-0 w-3.5 h-3.5 border-t-2 border-r-2 border-cyan-300 shadow-[0_0_8px_#38bdf8]" />
        <div className="absolute bottom-0 left-0 w-3.5 h-3.5 border-b-2 border-l-2 border-cyan-300 shadow-[0_0_8px_#38bdf8]" />
        <div className="absolute bottom-0 right-0 w-3.5 h-3.5 border-b-2 border-r-2 border-cyan-300 shadow-[0_0_8px_#38bdf8]" />

        {/* System Header Tag */}
        <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-cyan-950/90 border border-cyan-400 text-cyan-300 text-[9px] font-bold tracking-widest uppercase mb-2 shadow-[0_0_12px_#22d3ee]">
          <Zap className="w-3 h-3 text-cyan-400 animate-pulse" />
          <span>[ SYSTEM NOTIFICATION: RANK UP ]</span>
        </div>

        <h2 className="text-base font-black text-white tracking-widest uppercase drop-shadow-[0_0_8px_rgba(56,189,248,0.7)]">
          RANK ADVANCEMENT COMPLETE
        </h2>

        <p className="text-[10px] text-cyan-100/90 mt-1 font-sans leading-tight">
          The System has confirmed your consistency threshold. Your Hunter designation has ascended.
        </p>

        {/* Center Rank Showcase with Concentric Shockwave Aura Rings */}
        <div className="relative my-3.5 py-4 px-3 bg-slate-950/90 border border-cyan-500/60 rounded-xl overflow-hidden">
          {/* Centered Shockwave Rings */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-20 h-20 rounded-full border-2 border-cyan-400 animate-shockwave-1" />
            <div className="w-20 h-20 rounded-full border-2 border-blue-400 animate-shockwave-2" />
          </div>

          <div className="relative z-10 space-y-1">
            <div className="text-[9px] text-cyan-300 uppercase tracking-widest font-bold">
              {previousRankTitle ? `ADVANCED FROM ${previousRankTitle}` : 'NEW RANK UNLOCKED'}
            </div>
            
            <div className="text-4xl font-black text-cyan-300 tracking-widest animate-rank-glow py-0.5">
              {newRank.rank}
            </div>
            
            <div className="text-xs font-black text-white tracking-wider uppercase drop-shadow-[0_0_6px_#38bdf8]">
              "{newRank.title}"
            </div>
            
            <div className="text-[9px] text-cyan-200/80 font-sans pt-1 leading-snug">
              {newRank.lore}
            </div>
          </div>
        </div>

        {/* Stat Bonus Allocation */}
        <div className="grid grid-cols-2 gap-1.5 text-[9px] mb-3">
          <div className="p-1.5 rounded-lg bg-cyan-950/70 border border-cyan-500/40 text-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.2)]">
            <span className="text-stone-400 block text-[8px] uppercase tracking-wider">NEW LEVEL</span>
            <strong className="text-xs font-black text-white tracking-wider">LVL {level}</strong>
          </div>
          <div className="p-1.5 rounded-lg bg-cyan-950/70 border border-emerald-500/40 text-emerald-300 shadow-[0_0_10px_rgba(16,185,129,0.2)]">
            <span className="text-stone-400 block text-[8px] uppercase tracking-wider">STAT BONUS</span>
            <strong className="text-xs font-black text-emerald-300 tracking-wider">+10 ALL ATTRIBUTES</strong>
          </div>
        </div>

        {/* Claim / Confirm Button */}
        <button
          onClick={onClose}
          className="w-full py-2.5 bg-gradient-to-r from-cyan-400 via-sky-300 to-cyan-400 hover:brightness-110 active:brightness-95 text-slate-950 font-black text-xs rounded-xl tracking-widest uppercase shadow-[0_0_20px_rgba(56,189,248,0.8)] transition-all cursor-pointer flex items-center justify-center gap-1.5"
        >
          <Sparkles className="w-3.5 h-3.5 fill-slate-950 text-slate-950" />
          <span>[ CLAIM REPUTATION & CONTINUE ]</span>
        </button>
      </div>
    </div>
  );
};
