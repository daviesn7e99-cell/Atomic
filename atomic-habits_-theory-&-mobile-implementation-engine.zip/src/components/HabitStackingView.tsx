import React, { useState } from 'react';
import { 
  Link2, 
  Plus, 
  Headphones, 
  Clock, 
  Sunrise, 
  Sun, 
  Moon, 
  Layers,
  Zap
} from 'lucide-react';
import { Habit, TimeOfDay } from '../types/habits';

interface HabitStackingViewProps {
  habits: Habit[];
  onOpenNewHabitModal: () => void;
  onOpenTwoMinuteModal: (habit: Habit) => void;
  creatorName?: string;
}

export const HabitStackingView: React.FC<HabitStackingViewProps> = ({
  habits,
  onOpenNewHabitModal,
  onOpenTwoMinuteModal,
  creatorName = 'Jhondurd3n',
}) => {
  const [activeStackRoom, setActiveStackRoom] = useState<TimeOfDay>('morning');

  const stackRooms: { id: TimeOfDay; label: string; icon: any; desc: string }[] = [
    { id: 'morning', label: 'Morning Protocol', icon: Sunrise, desc: 'Awakening & morning beverage anchor' },
    { id: 'afternoon', label: 'Midday Focus', icon: Sun, desc: 'Workspace & combat focus anchor' },
    { id: 'evening', label: 'Evening Priming', icon: Moon, desc: 'Downtime preparation & tomorrow staging' },
  ];

  const filteredHabits = habits.filter((h) => h.timeOfDay === activeStackRoom);

  return (
    <div className="h-full flex flex-col justify-between gap-1.5 overflow-hidden text-xs font-mono">
      {/* Header Banner */}
      <div className="system-window rounded-xl p-2 shrink-0 border border-cyan-500/40">
        <div className="flex items-center justify-between pb-1 border-b border-cyan-950">
          <div className="flex items-center gap-1 text-cyan-400 text-[9px] font-bold uppercase tracking-wider">
            <Link2 className="w-3 h-3 text-cyan-400" />
            <span>[ SYSTEM: SKILL COMBO PROTOCOLS ]</span>
          </div>
          <span className="text-[8px] text-cyan-400/80">
            {filteredHabits.length} ACTIVE NODES
          </span>
        </div>
        <div className="text-[10px] font-black mt-0.5 text-white">
          "AFTER [CURRENT HABIT], I WILL [NEW HABIT]."
        </div>
        <p className="text-[8px] text-stone-300 font-sans leading-none mt-0.5">
          Chained behavioral circuits remove cognitive decision load.
        </p>
      </div>

      {/* Protocol Room Switcher Tabs */}
      <div className="grid grid-cols-3 gap-1 p-0.5 system-window rounded-lg shrink-0">
        {stackRooms.map((room) => {
          const Icon = room.icon;
          const isSelected = activeStackRoom === room.id;
          const count = habits.filter((h) => h.timeOfDay === room.id).length;

          return (
            <button
              key={room.id}
              onClick={() => setActiveStackRoom(room.id)}
              className={`py-1 px-1 rounded text-[8px] font-bold flex items-center justify-center gap-1 transition-all ${
                isSelected
                  ? 'bg-cyan-500 text-slate-950 shadow-[0_0_8px_#22d3ee]'
                  : 'text-stone-400 hover:text-cyan-300'
              }`}
            >
              <Icon className="w-2.5 h-2.5" />
              <span>{room.label.split(' ')[0]}</span>
              <span className="text-[7px] opacity-75">({count})</span>
            </button>
          );
        })}
      </div>

      {/* Sequential Combo Chain (Fits without scrolling) */}
      <div className="flex-1 min-h-0 system-window rounded-xl p-2 relative overflow-y-auto no-scrollbar">
        <div className="absolute left-[17px] top-4 bottom-4 w-0.5 bg-cyan-500/30" />

        <div className="space-y-1.5 relative">
          {filteredHabits.map((habit, idx) => (
            <div key={habit.id} className="flex items-start gap-2">
              <div className="w-4 h-4 rounded bg-cyan-500 text-slate-950 font-black text-[9px] flex items-center justify-center shrink-0 z-10 shadow-[0_0_6px_#22d3ee]">
                {idx + 1}
              </div>

              <div className="flex-1 bg-slate-950/80 border border-cyan-500/40 rounded p-1.5 hover:border-cyan-400 transition-colors">
                <div className="text-[8px] font-bold text-cyan-400 truncate">
                  [TRIGGER]: "{habit.anchorHabit}"
                </div>

                <div className="text-[10px] font-bold text-white font-sans truncate">
                  {habit.title}
                </div>

                {habit.temptationBundle && (
                  <div className="flex items-center gap-1 text-[8px] text-purple-300 mt-0.5 truncate">
                    <Headphones className="w-2.5 h-2.5 text-purple-400 shrink-0" />
                    <span className="truncate">Reward: {habit.temptationBundle}</span>
                  </div>
                )}

                <div className="mt-1 pt-1 border-t border-cyan-950 flex items-center justify-between text-[8px]">
                  <span className="text-stone-400 truncate max-w-[190px]">
                    Gateway: <strong className="text-cyan-300 font-medium">"{habit.twoMinuteVersion}"</strong>
                  </span>
                  <button
                    onClick={() => onOpenTwoMinuteModal(habit)}
                    className="text-cyan-400 font-bold hover:underline shrink-0"
                  >
                    [2m BURST]
                  </button>
                </div>
              </div>
            </div>
          ))}

          {filteredHabits.length === 0 && (
            <div className="text-center py-4 text-[9px] text-cyan-400/60">
              NO CHAIN NODES IN THIS ROOM.
            </div>
          )}
        </div>
      </div>

      {/* Register combo CTA */}
      <div className="pt-0.5 shrink-0">
        <button
          onClick={onOpenNewHabitModal}
          className="w-full h-8 rounded-lg bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-bold text-[9px] flex items-center justify-center gap-1 shadow-[0_0_10px_rgba(6,182,212,0.3)] hover:brightness-110 active:brightness-95 transition-all uppercase tracking-wider"
        >
          <Plus className="w-3 h-3" />
          <span>[ REGISTER SKILL COMBO ]</span>
        </button>
      </div>
    </div>
  );
};
