import React from 'react';
import { Award, Zap } from 'lucide-react';

interface DailyGoalCircularRingProps {
  completedCount: number;
  totalCount: number;
  size?: number; // default 42
}

export const DailyGoalCircularRing: React.FC<DailyGoalCircularRingProps> = ({
  completedCount,
  totalCount,
  size = 42,
}) => {
  const percentage = totalCount > 0 ? Math.min(100, Math.round((completedCount / totalCount) * 100)) : 0;
  const isAllComplete = totalCount > 0 && completedCount >= totalCount;

  // SVG Geometry
  const radius = 16;
  const strokeWidth = 3;
  const center = 21;
  const circumference = 2 * Math.PI * radius; // ~100.53
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <div 
      className="relative flex items-center justify-center shrink-0 select-none"
      style={{ width: size, height: size }}
      title={`Daily Quests Goal: ${completedCount}/${totalCount} (${percentage}%)`}
    >
      {/* Background Glow when 100% complete */}
      {isAllComplete && (
        <div className="absolute inset-0 rounded-full bg-cyan-400/20 blur-xs animate-pulse pointer-events-none" />
      )}

      {/* SVG Circular Progress Ring */}
      <svg
        viewBox="0 0 42 42"
        className="w-full h-full transform -rotate-90 overflow-visible"
      >
        <defs>
          <linearGradient id="goalManaGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#38bdf8" />
            <stop offset="50%" stopColor="#06b6d4" />
            <stop offset="100%" stopColor={isAllComplete ? '#10b981' : '#2563eb'} />
          </linearGradient>
          <filter id="goalGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="2" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Outer subtle tech boundary */}
        <circle
          cx={center}
          cy={center}
          r={radius + 2.5}
          fill="none"
          stroke="rgba(56, 189, 248, 0.15)"
          strokeWidth="0.8"
          strokeDasharray="2 3"
        />

        {/* Inactive track */}
        <circle
          cx={center}
          cy={center}
          r={radius}
          fill="rgba(3, 7, 18, 0.7)"
          stroke="rgba(8, 47, 73, 0.5)"
          strokeWidth={strokeWidth}
        />

        {/* Dynamic Animated Progress Arc */}
        <circle
          cx={center}
          cy={center}
          r={radius}
          fill="none"
          stroke="url(#goalManaGrad)"
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          filter={percentage > 0 ? 'url(#goalGlow)' : undefined}
          style={{
            transition: 'stroke-dashoffset 0.6s cubic-bezier(0.16, 1, 0.3, 1), stroke 0.4s ease',
          }}
        />
      </svg>

      {/* Center Percentage / Stat Display */}
      <div className="absolute inset-0 flex flex-col items-center justify-center leading-none text-center pointer-events-none">
        {isAllComplete ? (
          <span className="text-[8px] font-black text-emerald-300 drop-shadow-[0_0_6px_#34d399] tracking-tighter">
            100%
          </span>
        ) : (
          <>
            <span className="text-[9px] font-black text-cyan-300 font-mono tracking-tighter">
              {completedCount}/{totalCount}
            </span>
            <span className="text-[5.5px] font-bold text-stone-400 uppercase tracking-widest">
              GOAL
            </span>
          </>
        )}
      </div>
    </div>
  );
};
