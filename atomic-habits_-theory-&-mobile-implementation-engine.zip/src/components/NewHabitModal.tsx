import React, { useState } from 'react';
import { X, Sparkles, ArrowRight, ArrowLeft, Check, Zap } from 'lucide-react';
import { Habit, HabitCategory, TimeOfDay } from '../types/habits';

interface NewHabitModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveHabit: (habit: Habit) => void;
}

export const NewHabitModal: React.FC<NewHabitModalProps> = ({
  isOpen,
  onClose,
  onSaveHabit,
}) => {
  const [step, setStep] = useState(1);
  const [title, setTitle] = useState('');
  const [identityStatement, setIdentityStatement] = useState('');
  const [anchorHabit, setAnchorHabit] = useState('');
  const [twoMinuteVersion, setTwoMinuteVersion] = useState('');
  const [temptationBundle, setTemptationBundle] = useState('');
  const [timeOfDay, setTimeOfDay] = useState<TimeOfDay>('morning');
  const [category, setCategory] = useState<HabitCategory>('mind');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !anchorHabit.trim()) return;

    const newHabit: Habit = {
      id: `habit-${Date.now()}`,
      title: title.trim(),
      identityStatement: identityStatement.trim() || 'I am a disciplined Sovereign who masters every day.',
      anchorHabit: anchorHabit.trim().startsWith('After') ? anchorHabit.trim() : `After I ${anchorHabit.trim()}`,
      twoMinuteVersion: twoMinuteVersion.trim() || `Spend 2 minutes on ${title.trim()}`,
      temptationBundle: temptationBundle.trim() || undefined,
      timeOfDay,
      category,
      frequency: 'daily',
      completedDates: [],
      createdAt: new Date().toISOString().split('T')[0],
    };

    onSaveHabit(newHabit);
    handleReset();
    onClose();
  };

  const handleReset = () => {
    setStep(1);
    setTitle('');
    setIdentityStatement('');
    setAnchorHabit('');
    setTwoMinuteVersion('');
    setTemptationBundle('');
    setTimeOfDay('morning');
    setCategory('mind');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-in fade-in duration-150 text-xs font-mono">
      <div 
        className="w-full max-w-sm system-window rounded-2xl p-4 shadow-[0_0_30px_rgba(6,182,212,0.35)] relative overflow-hidden border border-cyan-400"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Hologram corner brackets */}
        <div className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-cyan-400" />
        <div className="absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 border-cyan-400" />
        <div className="absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-cyan-400" />
        <div className="absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-cyan-400" />

        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-cyan-500/40">
          <div>
            <div className="flex items-center gap-1 text-cyan-400 text-[9px] font-bold uppercase tracking-wider">
              <Zap className="w-3 h-3 text-cyan-400" />
              <span>[ STEP {step}/3: QUEST REGISTRATION ]</span>
            </div>
            <h3 className="text-xs font-bold text-white mt-0.5 font-sans">
              {step === 1 && '1. Identity Title & Trigger Cue'}
              {step === 2 && '2. 2-Min Gateway Ritual (Friction = 0)'}
              {step === 3 && '3. Reward Buff & Stat Room'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-6 h-6 rounded flex items-center justify-center text-cyan-400/80 hover:text-cyan-200 hover:bg-cyan-950/60 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="py-2.5 space-y-2.5">
          {step === 1 && (
            <div className="space-y-2">
              <div>
                <label className="text-[9px] text-cyan-400 uppercase tracking-wider block">
                  Quest Name <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. Pushups x 100 or Read 5 pages"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full mt-1 px-2.5 py-1.5 text-xs bg-slate-950 border border-cyan-500/50 rounded-lg text-white focus:outline-none focus:border-cyan-400 font-sans"
                  required
                  autoFocus
                />
              </div>

              <div>
                <label className="text-[9px] text-cyan-400 uppercase tracking-wider block">
                  Identity Archetype (Who do you become?)
                </label>
                <input
                  type="text"
                  placeholder="e.g. I am an invincible Shadow Monarch"
                  value={identityStatement}
                  onChange={(e) => setIdentityStatement(e.target.value)}
                  className="w-full mt-1 px-2.5 py-1.5 text-xs bg-slate-950 border border-cyan-500/50 rounded-lg text-white focus:outline-none focus:border-cyan-400 font-sans"
                />
              </div>

              <div>
                <label className="text-[9px] text-cyan-400 uppercase tracking-wider block">
                  Trigger Cue (Make It Obvious) <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. After I open my eyes and drink water..."
                  value={anchorHabit}
                  onChange={(e) => setAnchorHabit(e.target.value)}
                  className="w-full mt-1 px-2.5 py-1.5 text-xs bg-slate-950 border border-cyan-500/50 rounded-lg text-white focus:outline-none focus:border-cyan-400 font-sans"
                  required
                />
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-2">
              <div className="p-2 bg-cyan-950/60 border border-cyan-500/40 rounded-xl text-[9px] text-cyan-200">
                <strong>Law 3: Make It Easy.</strong> Scale down initial activation mana. The quest should take less than 120 seconds to begin.
              </div>

              <div>
                <label className="text-[9px] text-cyan-400 uppercase tracking-wider block">
                  2-Minute Gateway Ritual <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. Drop down and do 2 pushups immediately"
                  value={twoMinuteVersion}
                  onChange={(e) => setTwoMinuteVersion(e.target.value)}
                  className="w-full mt-1 px-2.5 py-1.5 text-xs bg-slate-950 border border-cyan-500/50 rounded-lg text-white focus:outline-none focus:border-cyan-400 font-sans"
                  required
                  autoFocus
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[9px] text-cyan-400 uppercase tracking-wider block">Stat Room</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as HabitCategory)}
                    className="w-full mt-1 px-2 py-1 text-xs bg-slate-950 border border-cyan-500/50 rounded-lg text-white"
                  >
                    <option value="health">Vitality [VIT]</option>
                    <option value="mind">Sense [SEN]</option>
                    <option value="craft">Intelligence [INT]</option>
                    <option value="focus">Strength [STR]</option>
                  </select>
                </div>
                <div>
                  <label className="text-[9px] text-cyan-400 uppercase tracking-wider block">Protocol Time</label>
                  <select
                    value={timeOfDay}
                    onChange={(e) => setTimeOfDay(e.target.value as TimeOfDay)}
                    className="w-full mt-1 px-2 py-1 text-xs bg-slate-950 border border-cyan-500/50 rounded-lg text-white"
                  >
                    <option value="morning">Morning</option>
                    <option value="afternoon">Afternoon</option>
                    <option value="evening">Evening</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-2">
              <div className="p-2 bg-purple-950/50 border border-purple-500/40 rounded-xl text-[9px] text-purple-200">
                <strong>Law 2: Make It Attractive.</strong> Temptation Bundling: pair what you need with an immediate high-dopamine unlock.
              </div>

              <div>
                <label className="text-[9px] text-cyan-400 uppercase tracking-wider block">
                  Reward Buff (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Listen to Solo Leveling OST only during execution"
                  value={temptationBundle}
                  onChange={(e) => setTemptationBundle(e.target.value)}
                  className="w-full mt-1 px-2.5 py-1.5 text-xs bg-slate-950 border border-cyan-500/50 rounded-lg text-white focus:outline-none focus:border-cyan-400 font-sans"
                  autoFocus
                />
              </div>

              <div className="p-2 bg-slate-950/80 rounded-xl border border-cyan-500/40 text-[9px] space-y-0.5">
                <span className="font-bold text-cyan-300 block">// QUEST BLUEPRINT:</span>
                <p className="text-stone-400"><strong>TRIGGER:</strong> {anchorHabit}</p>
                <p className="text-stone-400"><strong>ACTION:</strong> {title}</p>
                <p className="text-stone-400"><strong>GATEWAY:</strong> {twoMinuteVersion}</p>
              </div>
            </div>
          )}

          {/* Action buttons */}
          <div className="flex items-center justify-between pt-2 border-t border-cyan-900/50">
            {step > 1 ? (
              <button
                type="button"
                onClick={() => setStep(step - 1)}
                className="px-2.5 py-1 text-[10px] font-bold text-cyan-400 hover:text-white rounded flex items-center gap-1"
              >
                <ArrowLeft className="w-3 h-3" /> BACK
              </button>
            ) : (
              <button
                type="button"
                onClick={onClose}
                className="px-2.5 py-1 text-[10px] text-stone-400 hover:text-white"
              >
                CANCEL
              </button>
            )}

            {step < 3 ? (
              <button
                type="button"
                onClick={() => {
                  if (step === 1 && (!title.trim() || !anchorHabit.trim())) return;
                  if (step === 2 && !twoMinuteVersion.trim()) return;
                  setStep(step + 1);
                }}
                disabled={step === 1 ? !title.trim() || !anchorHabit.trim() : !twoMinuteVersion.trim()}
                className="px-3 py-1 text-[10px] font-bold bg-cyan-500 text-slate-950 rounded flex items-center gap-1 disabled:opacity-50 shadow-[0_0_8px_#22d3ee]"
              >
                NEXT <ArrowRight className="w-3 h-3" />
              </button>
            ) : (
              <button
                type="submit"
                className="px-3.5 py-1 text-[10px] font-black bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950 rounded flex items-center gap-1 shadow-[0_0_12px_#22d3ee] uppercase"
              >
                <Check className="w-3 h-3" /> [ ENGRAVE QUEST ]
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};
