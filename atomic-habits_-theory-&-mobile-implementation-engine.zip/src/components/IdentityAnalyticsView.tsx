import React, { useState } from 'react';
import { 
  Award, 
  TrendingUp, 
  ShieldCheck, 
  Zap,
  Activity
} from 'lucide-react';
import { Habit, IdentityProfile } from '../types/habits';
import { calculateHunterRank } from '../utils/rankProgression';

interface IdentityAnalyticsViewProps {
  habits: Habit[];
  identities: IdentityProfile[];
  creatorName?: string;
  onPreviewRankUp?: () => void;
}

export const IdentityAnalyticsView: React.FC<IdentityAnalyticsViewProps> = ({
  habits,
  identities,
  creatorName = 'Jhondurd3n',
  onPreviewRankUp,
}) => {
  const [activeAnalyticsRoom, setActiveAnalyticsRoom] = useState<'status' | 'compound' | 'penalty'>('status');
  const [simulationDays, setSimulationDays] = useState(365);
  const [dailyRate, setDailyRate] = useState(1.0);

  const totalVotesCast = habits.reduce(
    (sum, h) => sum + h.completedDates.length,
    0
  );

  const { currentRank, nextRank, level, remainingQuests, progressPercent } = calculateHunterRank(totalVotesCast);

  const identityVotes = identities.map((identity) => {
    const matchingHabits = habits.filter(
      (h) => identity.associatedHabits.includes(h.id) || h.identityStatement.toLowerCase().includes(identity.archetype.toLowerCase())
    );
    const votes = matchingHabits.reduce(
      (sum, h) => sum + h.completedDates.length,
      0
    );
    return {
      ...identity,
      votes,
      habitCount: matchingHabits.length,
    };
  });

  const calculateCompoundMultiplier = (ratePercent: number, days: number) => {
    const r = 1 + ratePercent / 100;
    return Math.pow(r, days);
  };

  const positiveMultiplier = calculateCompoundMultiplier(dailyRate, simulationDays);

  const generateCurvePoints = (multiplierFunc: (d: number) => number, height = 70, width = 300) => {
    const points: string[] = [];
    const steps = 30;
    for (let i = 0; i <= steps; i++) {
      const day = (i / steps) * simulationDays;
      const x = (i / steps) * width;
      const val = multiplierFunc(day);
      const maxVal = Math.max(positiveMultiplier, 10);
      const normalizedY = height - (Math.min(val, maxVal) / maxVal) * (height - 12) - 6;
      points.push(`${x},${normalizedY}`);
    }
    return points.join(' ');
  };

  const rooms = [
    { id: 'status', label: 'Hunter Status', icon: Award },
    { id: 'compound', label: '1% EXP Curve', icon: TrendingUp },
    { id: 'penalty', label: 'Penalty Evasion', icon: ShieldCheck },
  ] as const;

  return (
    <div className="h-full flex flex-col justify-between gap-1.5 overflow-hidden text-xs font-mono">
      {/* Header */}
      <div className="system-window rounded-xl p-2 shrink-0 border border-cyan-500/40">
        <div className="flex items-center justify-between pb-1 border-b border-cyan-950">
          <div className="flex items-center gap-1 text-cyan-400 text-[9px] font-bold uppercase tracking-wider">
            <Award className="w-3 h-3 text-cyan-400" />
            <span>[ SYSTEM: HUNTER EVALUATION MATRIX ]</span>
          </div>
          {onPreviewRankUp ? (
            <button
              onClick={onPreviewRankUp}
              className={`px-1.5 py-0.2 rounded border text-[8px] font-bold cursor-pointer hover:brightness-125 transition-all shadow-[0_0_6px_rgba(6,182,212,0.4)] ${currentRank.badgeColor}`}
              title="Click to trigger Rank Animation FX"
            >
              {currentRank.rank} ⚡
            </button>
          ) : (
            <span className={`px-1.5 py-0.2 rounded border text-[8px] font-bold ${currentRank.badgeColor}`}>
              {currentRank.rank}
            </span>
          )}
        </div>
        <div className="text-[10px] font-black mt-0.5 text-white flex items-center justify-between">
          <span>LVL {level} · "{currentRank.title}"</span>
          <span className="text-[8px] text-cyan-300 font-bold">{totalVotesCast} TOTAL QUESTS</span>
        </div>
      </div>

      {/* Analytics Room Switcher */}
      <div className="grid grid-cols-3 gap-1 p-0.5 system-window rounded-lg shrink-0">
        {rooms.map((r) => {
          const Icon = r.icon;
          const isSelected = activeAnalyticsRoom === r.id;
          return (
            <button
              key={r.id}
              onClick={() => setActiveAnalyticsRoom(r.id)}
              className={`py-1 px-1 rounded text-[8px] font-bold flex items-center justify-center gap-1 transition-all ${
                isSelected
                  ? 'bg-cyan-500 text-slate-950 shadow-[0_0_8px_#22d3ee]'
                  : 'text-stone-400 hover:text-cyan-300'
              }`}
            >
              <Icon className="w-2.5 h-2.5" />
              <span>{r.label}</span>
            </button>
          );
        })}
      </div>

      {/* Main Content Area (Fits cleanly in viewport) */}
      <div className="flex-1 min-h-0 system-window rounded-xl p-2 overflow-y-auto no-scrollbar">
        {activeAnalyticsRoom === 'status' && (
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-[8px] text-cyan-400/80 pb-0.5 border-b border-cyan-950">
              <span>// STAT ATTRIBUTES & VOTES</span>
              <span>EXP: {progressPercent}% TO NEXT RANK</span>
            </div>

            <div className="space-y-1">
              {identityVotes.map((item) => {
                const votePercent = totalVotesCast > 0 ? Math.round((item.votes / totalVotesCast) * 100) : 0;
                return (
                  <div
                    key={item.id}
                    className="p-1.5 bg-slate-950/80 border border-cyan-500/30 rounded space-y-0.5"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: item.color }} />
                        <span className="text-[9px] font-bold text-white uppercase font-sans">
                          {item.archetype}
                        </span>
                      </div>
                      <span className="text-[8px] font-bold text-cyan-300">
                        {item.votes} PTS ({votePercent}%)
                      </span>
                    </div>

                    <div className="w-full bg-slate-900 rounded-full h-1 overflow-hidden border border-cyan-950">
                      <div
                        className="h-full rounded-full transition-all duration-300 shadow-[0_0_4px_#22d3ee]"
                        style={{
                          width: `${Math.max(votePercent, 5)}%`,
                          backgroundColor: item.color,
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeAnalyticsRoom === 'compound' && (
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-[8px] text-cyan-400 pb-0.5 border-b border-cyan-950">
              <span>EXPONENTIAL GAIN SIMULATOR</span>
              <span className="font-bold">{positiveMultiplier.toFixed(1)}× STAT BOOST</span>
            </div>

            <div className="bg-black/90 border border-cyan-500/40 rounded p-1.5 text-white">
              <div className="h-16 w-full relative">
                <svg className="w-full h-full" viewBox="0 0 300 70" preserveAspectRatio="none">
                  <line x1="0" y1="50" x2="300" y2="50" stroke="#1e293b" strokeDasharray="2 2" />
                  <polyline
                    fill="none"
                    stroke="#22d3ee"
                    strokeWidth="2"
                    points={generateCurvePoints((d) => calculateCompoundMultiplier(dailyRate, d))}
                  />
                  <line x1="0" y1="58" x2="300" y2="58" stroke="#475569" strokeWidth="1" />
                </svg>
              </div>
              <div className="flex items-center justify-between text-[7px] text-stone-400 pt-0.5 border-t border-cyan-950">
                <span className="text-cyan-400">● 1% DAILY QUESTS</span>
                <span className="text-cyan-300">1.01³⁶⁵ = 37.78×</span>
              </div>
            </div>

            <div className="space-y-1 pt-0.5">
              <div className="flex justify-between text-[8px] text-cyan-400">
                <span>QUEST HORIZON: {simulationDays} DAYS</span>
                <span>{(simulationDays / 30).toFixed(1)} MONTHS</span>
              </div>
              <input
                type="range"
                min="30"
                max="365"
                step="5"
                value={simulationDays}
                onChange={(e) => setSimulationDays(Number(e.target.value))}
                className="w-full accent-cyan-400 h-1 bg-slate-900"
              />
            </div>
          </div>
        )}

        {activeAnalyticsRoom === 'penalty' && (
          <div className="space-y-1.5">
            <div className="text-[8px] font-bold text-rose-400 uppercase pb-0.5 border-b border-rose-950">
              [ SYSTEM PROTOCOL: NEVER MISS TWICE ]
            </div>
            <div className="p-1.5 bg-slate-950/80 border border-cyan-500/30 rounded text-[8px] text-stone-300 space-y-0.5">
              <strong className="text-cyan-300 block">The Single Miss Immunity:</strong>
              <p className="font-sans leading-snug">
                Missing 1 day is treated as an unexpected injury. Your Rank and Level remain preserved.
              </p>
            </div>
            <div className="p-1.5 system-alert-window rounded text-[8px] text-rose-200 space-y-0.5">
              <strong className="text-rose-400 block">The 2nd Day Mandate:</strong>
              <p className="font-sans leading-snug">
                Missing 2 consecutive days triggers the Penalty Zone. Rebound immediately on Day 2 to cancel the threat.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
