import React from 'react';
import { Check } from 'lucide-react';

interface HabitCircularCheckboxProps {
  isDone: boolean;
  onToggle: () => void;
  title: string;
  size?: number; // size in px, default 36
}

export const HabitCircularCheckbox: React.FC<HabitCircularCheckboxProps> = ({
  isDone,
  onToggle,
  title,
  size = 36,
}) => {
  // SVG Geometry
  const radius = 13.5;
  const strokeWidth = 2.5;
  const center = 18;
  const circumference = 2 * Math.PI * radius; // ~84.82
  const strokeDashoffset = isDone ? 0 : circumference;

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onToggle();
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      aria-label={`${isDone ? 'Mark uncompleted' : 'Complete quest'}: ${title}`}
      className="relative flex items-center justify-center shrink-0 cursor-pointer group focus:outline-none select-none"
      style={{ width: size, height: size }}
    >
      {/* Outer subtle static cyberpunk ring container - fixed in place */}
      <div 
        className={`absolute inset-0.5 rounded-full transition-colors duration-300 pointer-events-none ${
          isDone 
            ? 'bg-cyan-500/15 shadow-[0_0_10px_rgba(6,182,212,0.35)]' 
            : 'bg-slate-950/80 group-hover:bg-cyan-950/40'
        }`} 
      />

      {/* Circular Progress Ring SVG - strictly anchored, no zoom */}
      <svg
        viewBox="0 0 36 36"
        className="w-full h-full transform -rotate-90 relative z-10 overflow-visible pointer-events-none"
      >
        <defs>
          <linearGradient id="cyanManaGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#38bdf8" />
            <stop offset="50%" stopColor="#06b6d4" />
            <stop offset="100%" stopColor="#2563eb" />
          </linearGradient>
          <filter id="ringGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="1.2" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* 1. Track circle (empty background ring) */}
        <circle
          cx={center}
          cy={center}
          r={radius}
          fill="none"
          stroke="rgba(8, 47, 73, 0.45)"
          strokeWidth={strokeWidth}
          className="transition-colors duration-200 group-hover:stroke-cyan-900/80"
        />

        {/* 2. Cyberpunk system cardinal ticks - strictly fixed */}
        <circle cx={center} cy={center - radius} r="0.8" fill="rgba(56, 189, 248, 0.5)" />
        <circle cx={center + radius} cy={center} r="0.8" fill="rgba(56, 189, 248, 0.5)" />
        <circle cx={center} cy={center + radius} r="0.8" fill="rgba(56, 189, 248, 0.5)" />
        <circle cx={center - radius} cy={center} r="0.8" fill="rgba(56, 189, 248, 0.5)" />

        {/* 3. Animated Progress Ring that fills up on completion without any scaling/zoom */}
        <circle
          cx={center}
          cy={center}
          r={radius}
          fill="none"
          stroke="url(#cyanManaGrad)"
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          filter={isDone ? 'url(#ringGlow)' : undefined}
          style={{
            transition: 'stroke-dashoffset 0.4s cubic-bezier(0.16, 1, 0.3, 1), stroke 0.2s ease',
          }}
        />
      </svg>

      {/* Center indicator - strictly fixed in place, zero zoom/scale */}
      <div className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none">
        {isDone ? (
          <Check 
            className="w-3.5 h-3.5 text-cyan-200 stroke-[3.5] drop-shadow-[0_0_4px_#38bdf8] transition-opacity duration-200" 
          />
        ) : (
          <div className="flex items-center justify-center">
            {/* Uncompleted Idle Core: steady indicator, no zoom */}
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-500/40 group-hover:bg-cyan-300 group-hover:shadow-[0_0_6px_#38bdf8] transition-colors duration-200" />
            <span className="absolute w-3 h-3 rounded-full border border-cyan-500/20 group-hover:border-cyan-400/50 transition-colors duration-200" />
          </div>
        )}
      </div>
    </button>
  );
};
