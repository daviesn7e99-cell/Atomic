import React, { useState, useEffect } from 'react';
import { X, Play, Pause, RotateCcw, CheckCircle2, Zap, ShieldAlert, Sparkles } from 'lucide-react';
import { Habit } from '../types/habits';

interface TwoMinuteTimerModalProps {
  habit: Habit | null;
  onClose: () => void;
  onComplete: (habitId: string) => void;
}

export const TwoMinuteTimerModal: React.FC<TwoMinuteTimerModalProps> = ({
  habit,
  onClose,
  onComplete,
}) => {
  const [secondsLeft, setSecondsLeft] = useState(120);
  const [isActive, setIsActive] = useState(false);
  const [isFinished, setIsFinished] = useState(false);

  useEffect(() => {
    let interval: ReturnType<typeof setInterval> | null = null;
    if (isActive && secondsLeft > 0) {
      interval = setInterval(() => {
        setSecondsLeft((prev) => prev - 1);
      }, 1000);
    } else if (secondsLeft === 0) {
      setIsActive(false);
      setIsFinished(true);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isActive, secondsLeft]);

  if (!habit) return null;

  const minutes = Math.floor(secondsLeft / 60);
  const seconds = secondsLeft % 60;
  const progressPercent = ((120 - secondsLeft) / 120) * 100;

  const handleFinish = () => {
    onComplete(habit.id);
    onClose();
  };

  const handleReset = () => {
    setIsActive(false);
    setSecondsLeft(120);
    setIsFinished(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-md animate-in fade-in duration-150 text-xs">
      <div 
        className="w-full max-w-sm system-window rounded-2xl p-4 shadow-[0_0_30px_rgba(6,182,212,0.35)] relative overflow-hidden border border-cyan-400"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Holographic corner markers */}
        <div className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-cyan-400" />
        <div className="absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 border-cyan-400" />
        <div className="absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-cyan-400" />
        <div className="absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-cyan-400" />

        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-cyan-500/40">
          <div className="flex items-center gap-1.5 font-mono text-[10px] text-cyan-400 font-bold uppercase tracking-widest">
            <Zap className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            <span>[ SYSTEM: 120s GATEWAY BURST ]</span>
          </div>
          <button
            onClick={onClose}
            className="w-6 h-6 rounded flex items-center justify-center text-cyan-400/80 hover:text-cyan-200 hover:bg-cyan-950/60 transition-colors"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quest Title & Gateway Ritual */}
        <div className="py-3 text-center">
          <div className="text-[10px] font-mono text-cyan-400 uppercase tracking-wider">
            TARGET QUEST
          </div>
          <h3 className="text-sm font-bold text-white tracking-tight mt-0.5">
            {habit.title}
          </h3>
          
          <div className="mt-2.5 p-2 bg-cyan-950/60 border border-cyan-500/50 rounded-xl text-left">
            <div className="text-[9px] font-mono font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1">
              <span>GATEWAY RITUAL (FRICTION = 0)</span>
            </div>
            <p className="text-[11px] font-medium text-cyan-100 mt-0.5 leading-snug">
              "{habit.twoMinuteVersion}"
            </p>
          </div>

          {/* Glowing Circular Mana Timer */}
          <div className="my-3 flex flex-col items-center justify-center">
            <div className="relative w-28 h-28 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r="44"
                  className="stroke-slate-900"
                  strokeWidth="5"
                  fill="none"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="44"
                  className="stroke-cyan-400 transition-all duration-300 drop-shadow-[0_0_8px_#22d3ee]"
                  strokeWidth="5"
                  strokeDasharray={276.4}
                  strokeDashoffset={276.4 - (276.4 * progressPercent) / 100}
                  strokeLinecap="round"
                  fill="none"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-2xl font-black font-mono tabular-nums text-white drop-shadow-[0_0_10px_#22d3ee]">
                  {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
                </span>
                <span className="text-[9px] font-mono text-cyan-400 font-bold uppercase tracking-wider mt-0.5">
                  {isActive ? 'BURST ACTIVE' : isFinished ? 'RITUAL MET' : 'STANDBY'}
                </span>
              </div>
            </div>
          </div>

          <p className="text-[9px] font-mono text-stone-400 max-w-xs mx-auto leading-snug">
            "Standardize before you optimize. A habit must be established before it can be improved."
          </p>

          {/* Action buttons */}
          <div className="mt-3.5 flex items-center justify-center gap-2">
            {!isFinished ? (
              <>
                <button
                  onClick={handleReset}
                  className="h-8 w-8 rounded-lg border border-cyan-800 bg-slate-950/80 text-cyan-400 flex items-center justify-center hover:bg-cyan-950"
                  title="Reset"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setIsActive(!isActive)}
                  className={`h-8 px-4 rounded-lg font-mono font-bold text-xs flex items-center gap-1.5 transition-all shadow-md ${
                    isActive
                      ? 'bg-amber-600 hover:bg-amber-700 text-white'
                      : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-[0_0_15px_rgba(6,182,212,0.5)]'
                  }`}
                >
                  {isActive ? <><Pause className="w-3.5 h-3.5" /> PAUSE</> : <><Play className="w-3.5 h-3.5 fill-current" /> ENGAGE 2m</>}
                </button>
                <button
                  onClick={handleFinish}
                  className="h-8 px-2.5 rounded-lg border border-cyan-500/40 bg-cyan-950/50 text-cyan-300 text-[10px] font-mono font-bold flex items-center gap-1 hover:bg-cyan-900/60"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" /> DONE
                </button>
              </>
            ) : (
              <button
                onClick={handleFinish}
                className="w-full h-9 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:brightness-110 text-slate-950 font-mono font-black text-xs flex items-center justify-center gap-1.5 shadow-[0_0_20px_rgba(6,182,212,0.6)] uppercase tracking-wider"
              >
                <Sparkles className="w-3.5 h-3.5" /> [ CLAIM VICTORY & LEVEL UP ]
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
