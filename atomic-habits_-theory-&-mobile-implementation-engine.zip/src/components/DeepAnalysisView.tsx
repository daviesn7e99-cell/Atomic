import React, { useState } from 'react';
import { 
  BookOpen, 
  Layers, 
  Cpu, 
  XCircle,
  Zap
} from 'lucide-react';
import { FOUR_LAWS_ANALYSIS, LawDetail } from '../data/atomicHabitsGuide';

interface DeepAnalysisViewProps {
  creatorName?: string;
}

export const DeepAnalysisView: React.FC<DeepAnalysisViewProps> = ({
  creatorName = 'Jhondurd3n',
}) => {
  const [activeAnalysisRoom, setActiveAnalysisRoom] = useState<'laws' | 'layers' | 'comparison' | 'engineering'>('laws');
  const [selectedLawIndex, setSelectedLawIndex] = useState(0);
  const activeLaw: LawDetail = FOUR_LAWS_ANALYSIS[selectedLawIndex];

  const analysisRooms = [
    { id: 'laws', label: 'The 4 Laws', icon: BookOpen },
    { id: 'layers', label: 'Identity Layers', icon: Layers },
    { id: 'comparison', label: 'Comparison', icon: XCircle },
    { id: 'engineering', label: 'Blueprint', icon: Cpu },
  ] as const;

  return (
    <div className="h-full flex flex-col justify-between gap-1.5 overflow-hidden text-xs font-mono">
      {/* Header */}
      <div className="system-window rounded-xl p-2 shrink-0 border border-cyan-500/40">
        <div className="flex items-center justify-between pb-0.5 border-b border-cyan-950">
          <div className="flex items-center gap-1 text-cyan-400 text-[9px] font-bold uppercase tracking-wider">
            <BookOpen className="w-3 h-3 text-cyan-400" />
            <span>[ SYSTEM: ARCHIVE & PROTOCOLS ]</span>
          </div>
          <span className="text-[8px] text-cyan-400/80">
            BY {creatorName.toUpperCase()}
          </span>
        </div>
        <div className="text-[10px] font-black mt-0.5 text-white">
          THE 4 LAWS OF BEHAVIOR CHANGE IN MOBILE SYSTEMS
        </div>
      </div>

      {/* Analysis Category Rooms Switcher */}
      <div className="grid grid-cols-4 gap-1 p-0.5 system-window rounded-lg shrink-0">
        {analysisRooms.map((r) => {
          const Icon = r.icon;
          const isSelected = activeAnalysisRoom === r.id;
          return (
            <button
              key={r.id}
              onClick={() => setActiveAnalysisRoom(r.id)}
              className={`py-1 px-0.5 rounded text-[8px] font-bold flex items-center justify-center gap-1 transition-all ${
                isSelected
                  ? 'bg-cyan-500 text-slate-950 shadow-[0_0_8px_#22d3ee]'
                  : 'text-stone-400 hover:text-cyan-300'
              }`}
            >
              <Icon className="w-2.5 h-2.5" />
              <span>{r.label.split(' ')[0]}</span>
            </button>
          );
        })}
      </div>

      {/* Main Content Area (Fits cleanly in viewport) */}
      <div className="flex-1 min-h-0 system-window rounded-xl p-2 overflow-y-auto no-scrollbar">
        {activeAnalysisRoom === 'laws' && (
          <div className="space-y-1.5">
            <div className="grid grid-cols-4 gap-1">
              {FOUR_LAWS_ANALYSIS.map((law, idx) => (
                <button
                  key={law.number}
                  onClick={() => setSelectedLawIndex(idx)}
                  className={`py-0.5 px-0.5 rounded text-center border text-[8px] font-bold ${
                    selectedLawIndex === idx
                      ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-[0_0_6px_#22d3ee]'
                      : 'bg-slate-950/70 border-cyan-900/60 text-cyan-400/80 hover:border-cyan-700'
                  }`}
                >
                  LAW {law.number}
                </button>
              ))}
            </div>

            <div className="p-1.5 bg-slate-950/80 border border-cyan-500/40 rounded space-y-1 text-[9px]">
              <div className="flex items-center gap-1">
                <span className="px-1 py-0.2 rounded text-[7px] font-bold bg-cyan-950 border border-cyan-500/50 text-cyan-300">
                  {activeLaw.stage.toUpperCase()}
                </span>
                <span className="font-bold text-white">
                  LAW {activeLaw.number}: {activeLaw.name.toUpperCase()}
                </span>
              </div>
              <p className="text-[8px] text-stone-300 font-sans leading-snug">
                {activeLaw.principle}
              </p>
              <div className="p-1 bg-cyan-950/50 rounded border border-cyan-500/30 text-[8px]">
                <strong className="text-cyan-300 block">[MOBILE HUD]:</strong>
                <span className="text-cyan-100 font-sans">{activeLaw.mobileImplementation.uxPattern}</span>
              </div>
            </div>
          </div>
        )}

        {activeAnalysisRoom === 'layers' && (
          <div className="space-y-1 text-[9px]">
            <div className="p-1.5 bg-slate-950/80 rounded border border-cyan-900/50">
              <strong className="text-stone-300 block font-mono">1. OUTCOMES (OUTER)</strong>
              <p className="text-[8px] text-stone-400 font-sans">External trophies and metrics. Fragile and fleeting.</p>
            </div>
            <div className="p-1.5 bg-slate-950/80 rounded border border-cyan-900/50">
              <strong className="text-stone-300 block font-mono">2. PROCESSES (MIDDLE)</strong>
              <p className="text-[8px] text-stone-400 font-sans">The daily quest stacks that power the hunter system.</p>
            </div>
            <div className="p-1.5 bg-cyan-950/60 rounded border border-cyan-400">
              <strong className="text-cyan-300 block font-mono">3. IDENTITY (CORE MONARCH)</strong>
              <p className="text-[8px] text-cyan-100 font-sans">
                "I am a Sovereign." Every completed quest is an indisputable vote for your transformation.
              </p>
            </div>
          </div>
        )}

        {activeAnalysisRoom === 'comparison' && (
          <div className="space-y-1 text-[8px] font-sans">
            <div className="p-1.5 rounded bg-slate-950/80 border border-cyan-900/40 space-y-0.5">
              <strong className="text-white font-mono block">1. STREAK SHAMING VS NEVER MISS TWICE</strong>
              <div className="text-rose-400">✗ Traditional: Resets to 0, inducing user abandonment.</div>
              <div className="text-cyan-300">✓ System: Never Miss Twice preserves identity on Day 2.</div>
            </div>
            <div className="p-1.5 rounded bg-slate-950/80 border border-cyan-900/40 space-y-0.5">
              <strong className="text-white font-mono block">2. STARTING RESISTANCE VS 2-MIN GATEWAY</strong>
              <div className="text-rose-400">✗ Traditional: Demands full 60m workout, skipped when tired.</div>
              <div className="text-cyan-300">✓ System: 2-minute gateway ritual establishes momentum.</div>
            </div>
          </div>
        )}

        {activeAnalysisRoom === 'engineering' && (
          <div className="space-y-1 text-[8px] font-sans">
            <div className="p-1.5 rounded bg-slate-950/80 border border-cyan-900/40">
              <strong className="text-cyan-300 block font-mono">1. LOCAL OFFLINE STORAGE</strong>
              <p className="text-stone-400">Instant sub-50ms local DB writes with 100% offline PWA caching.</p>
            </div>
            <div className="p-1.5 rounded bg-slate-950/80 border border-cyan-900/40">
              <strong className="text-cyan-300 block font-mono">2. LOCKSCREEN WIDGET INTERFACES</strong>
              <p className="text-stone-400">Direct interactive widget check-ins without entering phone apps.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
