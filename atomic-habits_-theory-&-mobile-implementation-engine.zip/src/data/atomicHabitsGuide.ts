export interface LawDetail {
  number: number;
  name: string;
  stage: 'Cue' | 'Craving' | 'Response' | 'Reward';
  principle: string;
  psychologicalMechanism: string;
  bookTactics: string[];
  inversion: {
    rule: string;
    tactic: string;
  };
  mobileImplementation: {
    featureName: string;
    uxPattern: string;
    technicalImplementation: string;
    antiPatternToAvoid: string;
  };
}

export const FOUR_LAWS_ANALYSIS: LawDetail[] = [
  {
    number: 1,
    name: 'Make It Obvious',
    stage: 'Cue',
    principle: 'Awareness precedes execution. The cues that spark a habit must stand out unmistakably in your physical and digital environments.',
    psychologicalMechanism: 'The brain is a prediction machine. Visual, spatial, and temporal triggers initiate dopamine-mediated anticipatory firing before conscious choice occurs.',
    bookTactics: [
      'Implementation Intentions: "I will [BEHAVIOR] at [TIME] in [LOCATION]"',
      'Habit Stacking: "After [CURRENT HABIT], I will [NEW HABIT]"',
      'Environment Design: Make the cues of good habits prominent and visible',
      'Habit Scorecard: Point-and-call tracking of unconscious daily rituals (+, -, =)'
    ],
    inversion: {
      rule: 'Make It Invisible',
      tactic: 'Reduce exposure to the cue. Remove toxic triggers from view (e.g., charge phone in another room; uninstall time-sink apps).'
    },
    mobileImplementation: {
      featureName: 'Contextual Cue Stacking Engine & Smart Widgets',
      uxPattern: 'Sequential Habit Chains (A triggers B). Habit cards visually link together, showing the physical anchor ("After brewing coffee") prominently instead of arbitrary times.',
      technicalImplementation: 'Lock-screen interactive widgets, geo-fenced trigger prompts, and sequential push notifications timed relative to routine anchors rather than rigid clocks.',
      antiPatternToAvoid: 'Bombarding users with 10 generic alarms at 08:00 AM that become background noise and induce notification blindness.'
    }
  },
  {
    number: 2,
    name: 'Make It Attractive',
    stage: 'Craving',
    principle: 'Desire drives behavior. It is the anticipation of a reward—not the fulfillment of it—that releases dopamine and gets us to act.',
    psychologicalMechanism: 'Mesolimbic dopamine pathway fires at the cue in proportion to expected hedonic value. Craving is the motivational motor.',
    bookTactics: [
      'Temptation Bundling (Premack\'s Principle): Pair an action you NEED to do with an action you WANT to do',
      'Cultural Identity Alignment: Join a culture where your desired behavior is the normal behavior',
      'Reframing Mindsets: Shift from "I have to" to "I get to"'
    ],
    inversion: {
      rule: 'Make It Unattractive',
      tactic: 'Reframe your mindset to highlight the immediate emotional and physical costs of bad habits.'
    },
    mobileImplementation: {
      featureName: 'Temptation Bundling & Identity Affirmation Cards',
      uxPattern: 'Directly attaching high-pleasure unlocks (e.g., favorite podcast, designated coffee, reading fiction) inside the habit execution card with integrated media triggers.',
      technicalImplementation: 'Quick-launch deep links to bundled media (audiobooks, spotify focus playlists) upon habit initiation, paired with celebratory visual reinforcement.',
      antiPatternToAvoid: 'Cold corporate checklist style with generic checkmarks and no emotional resonance or anticipation.'
    }
  },
  {
    number: 3,
    name: 'Make It Easy',
    stage: 'Response',
    principle: 'Human behavior follows the Law of Least Effort. The actual execution must have near-zero physical, mental, and cognitive friction.',
    psychologicalMechanism: 'Action potential threshold in neural pathways. When starting effort is high, the prefrontal cortex vetoes execution. Shrinking the threshold bypasses resistance.',
    bookTactics: [
      'The 2-Minute Rule: "When you start a new habit, it should take less than two minutes to do"',
      'Gateway Habits: The initial action that automatically leads into the productive phase (e.g., putting on running shoes)',
      'Prime the Environment: Prepare your tools and space in advance so starting is frictionless',
      'Master the Decisive Moments: Tiny choices throughout the day that deliver an outsized impact'
    ],
    inversion: {
      rule: 'Make It Difficult',
      tactic: 'Increase friction. Add steps between you and bad habits (e.g., lock apps behind passwords, unplug television).'
    },
    mobileImplementation: {
      featureName: '1-Tap Logging & Interactive 2-Minute Starter Timer',
      uxPattern: 'A dedicated "2-Minute Start" button on each habit row. If the user feels overwhelmed or resistant, they tap this to start a simple 120-second countdown for the gateway ritual.',
      technicalImplementation: 'Offline-first instant tap check-ins, zero-navigation interactive home screen widgets, and sub-100ms micro-interaction latency.',
      antiPatternToAvoid: 'Requiring multi-step form entry, tedious tag dropdowns, and deep modal navigation just to record a 30-second glass of water.'
    }
  },
  {
    number: 4,
    name: 'Make It Satisfying',
    stage: 'Reward',
    principle: 'What is immediately rewarded is repeated. What is immediately punished is avoided. Immediate satisfaction bridges the delay between effort and long-term payoff.',
    psychologicalMechanism: 'Operant conditioning & modern mismatch: humans evolved for an Immediate Return Environment, but modern habits have Delayed Return payoffs.',
    bookTactics: [
      'Visual Habit Tracking: Moving paperclips or marking an X provides tangible proof of progress',
      'The Cardinal Rule of Habit Tracking: "Never Miss Twice"',
      'Immediate Micro-Reinforcement: Celebrate small wins to close the emotional feedback loop',
      'Habit Contracts & Accountability: Making the costs of inaction public and immediate'
    ],
    inversion: {
      rule: 'Make It Unsatisfying',
      tactic: 'Create immediate consequences for bad habits (e.g., accountability partner forfeits, public commitments).'
    },
    mobileImplementation: {
      featureName: 'Identity Voting Tally & "Never Miss Twice" Safety Net',
      uxPattern: 'Instead of punishing streaks that shatter into zero after one busy day, the app treats every completion as a "Cast Vote for Your Identity". If yesterday was missed, it highlights "Protect the Chain: Never Miss Twice" in an encouraging, non-punitive tone.',
      technicalImplementation: 'Micro-haptics, particle satisfaction animations, identity vote accumulators, and grace day algorithms that protect psychological momentum.',
      antiPatternToAvoid: 'Demoralizing "Streak Reset: Day 0" shame banners that cause users to abandon the app after 3 weeks (the Valley of Disappointment).'
    }
  }
];

export const CORE_CONCEPTS = [
  {
    title: 'The Aggregation of Marginal Gains (1% Better Every Day)',
    formula: '1.01^{365} = 37.78 \\quad\\text{vs}\\quad 0.99^{365} = 0.03',
    summary: 'Habits are the compound interest of self-improvement. Getting 1% better each day compounds into a 37-fold improvement over one year, whereas slipping 1% worse reduces you to nearly zero.',
    appTranslation: 'The mobile app must make invisible compound gains visible through cumulative identity vote metrics and compound curve simulations, preventing early dropout before the inflection point.'
  },
  {
    title: 'The Plateau of Latent Potential ("The Valley of Disappointment")',
    formula: '\\text{Effort} \\gg \\text{Visible Results (Lagging Phase)}',
    summary: 'Results are often delayed. In the first days or weeks, your efforts appear wasted because work is being stored, not destroyed—like heating an ice cube from 25°F to 31°F. At 32°F, the phase shift occurs.',
    appTranslation: 'A mobile tracker must provide immediate process-based feedback (votes cast, stacks completed) rather than waiting for outcome metrics (e.g., weight lost or books published).'
  },
  {
    title: 'Identity-Based Habits vs. Outcome-Based Habits',
    formula: '\\text{Identity (Core)} \\rightarrow \\text{Processes (System)} \\rightarrow \\text{Outcomes (Goal)}',
    summary: 'Most people focus on what they want to achieve (outcomes). Lasting change occurs when you focus on who you wish to become (identity). "The goal is not to read a book, the goal is to become a reader."',
    appTranslation: 'Every habit in the app is anchored directly to an explicit identity statement. Checking off a habit increments the "Votes Cast for [Identity]" counter, changing the user\'s self-image.'
  },
  {
    title: 'The "Never Miss Twice" Rule',
    formula: '\\text{1 Miss} = \\text{Accident} \\quad | \\quad \\text{2 Misses} = \\text{The Start of a New Bad Habit}',
    summary: 'Perfection is impossible. Top performers don\'t avoid failure; they rebound immediately. Missing once is an outlier; missing twice begins a new counter-habit.',
    appTranslation: 'When a habit is missed on day T-1, day T displays an encouraging "Never Miss Twice" badge. Completing day T preserves streak integrity and earns a "Resilience Vote".'
  }
];
