export interface HunterRankInfo {
  rank: string;
  title: string;
  minCompleted: number;
  nextThreshold: number;
  badgeColor: string;
  textColor: string;
  glowColor: string;
  lore: string;
}

export const HUNTER_RANKS: HunterRankInfo[] = [
  {
    rank: 'E-RANK',
    title: 'The Weakest Hunter',
    minCompleted: 0,
    nextThreshold: 5,
    badgeColor: 'border-stone-600 bg-stone-900/90 text-stone-300',
    textColor: 'text-stone-400',
    glowColor: 'rgba(120, 113, 108, 0.3)',
    lore: 'At the bottom rung of the Association. Surviving through pure instinct and daily discipline.',
  },
  {
    rank: 'D-RANK',
    title: 'The Awakening Striker',
    minCompleted: 5,
    nextThreshold: 12,
    badgeColor: 'border-emerald-600 bg-emerald-950/80 text-emerald-300',
    textColor: 'text-emerald-400',
    glowColor: 'rgba(16, 185, 129, 0.4)',
    lore: 'The initial spark of mana ignites. Habits begin forming neural pathways.',
  },
  {
    rank: 'C-RANK',
    title: 'The Dungeon Pioneer',
    minCompleted: 12,
    nextThreshold: 22,
    badgeColor: 'border-blue-600 bg-blue-950/80 text-blue-300',
    textColor: 'text-blue-400',
    glowColor: 'rgba(59, 130, 246, 0.4)',
    lore: 'Consistent daily execution unlocks steady physical and mental mastery.',
  },
  {
    rank: 'B-RANK',
    title: 'The Elite Vanguard',
    minCompleted: 22,
    nextThreshold: 35,
    badgeColor: 'border-purple-600 bg-purple-950/80 text-purple-300',
    textColor: 'text-purple-400',
    glowColor: 'rgba(168, 85, 247, 0.4)',
    lore: 'Formidable behavioral momentum. Starting resistance is reduced to zero.',
  },
  {
    rank: 'A-RANK',
    title: 'High-Rank Monarch Disciple',
    minCompleted: 35,
    nextThreshold: 55,
    badgeColor: 'border-amber-600 bg-amber-950/80 text-amber-300',
    textColor: 'text-amber-400',
    glowColor: 'rgba(245, 158, 11, 0.4)',
    lore: 'Recognized by the System as a top performer. Habits are now second nature.',
  },
  {
    rank: 'S-RANK',
    title: 'The Shadow Monarch',
    minCompleted: 55,
    nextThreshold: 80,
    badgeColor: 'border-cyan-400 bg-cyan-950/90 text-cyan-200',
    textColor: 'text-cyan-300',
    glowColor: 'rgba(6, 182, 212, 0.6)',
    lore: 'Supreme sovereignty over attention and daily rituals. The Shadow Army executes on command.',
  },
  {
    rank: 'NATIONAL LEVEL',
    title: 'Sovereign of Atomic Habits',
    minCompleted: 80,
    nextThreshold: 120,
    badgeColor: 'border-yellow-400 bg-yellow-950/90 text-yellow-200',
    textColor: 'text-yellow-300',
    glowColor: 'rgba(234, 179, 8, 0.7)',
    lore: 'Transmuted identity beyond limits. Compounding gains reach theoretical peak.',
  },
];

export function calculateHunterRank(totalCompleted: number): {
  currentRank: HunterRankInfo;
  nextRank: HunterRankInfo | null;
  progressPercent: number;
  remainingQuests: number;
  level: number;
} {
  let currentRankIndex = 0;
  for (let i = HUNTER_RANKS.length - 1; i >= 0; i--) {
    if (totalCompleted >= HUNTER_RANKS[i].minCompleted) {
      currentRankIndex = i;
      break;
    }
  }

  const currentRank = HUNTER_RANKS[currentRankIndex];
  const nextRank = currentRankIndex < HUNTER_RANKS.length - 1 ? HUNTER_RANKS[currentRankIndex + 1] : null;

  let progressPercent = 100;
  let remainingQuests = 0;

  if (nextRank) {
    const range = nextRank.minCompleted - currentRank.minCompleted;
    const currentProgress = totalCompleted - currentRank.minCompleted;
    progressPercent = Math.min(100, Math.max(0, Math.round((currentProgress / range) * 100)));
    remainingQuests = nextRank.minCompleted - totalCompleted;
  }

  // Level: Starts at Level 0 and increments as quests are completed
  const level = Math.floor(totalCompleted / 2);

  return {
    currentRank,
    nextRank,
    progressPercent,
    remainingQuests,
    level,
  };
}
