import React, { useState, useEffect } from 'react';
import { 
  CalendarCheck, 
  Link2, 
  ClipboardCheck, 
  Award, 
  BookOpen, 
  Settings, 
  Download, 
  Wifi, 
  WifiOff,
  Zap
} from 'lucide-react';
import { Habit, ScorecardItem, TimeOfDay } from './types/habits';
import { INITIAL_HABITS, INITIAL_SCORECARD, INITIAL_IDENTITIES } from './data/initialHabits';
import { TodayHabitsView } from './components/TodayHabitsView';
import { HabitStackingView } from './components/HabitStackingView';
import { ScorecardView } from './components/ScorecardView';
import { IdentityAnalyticsView } from './components/IdentityAnalyticsView';
import { DeepAnalysisView } from './components/DeepAnalysisView';
import { TwoMinuteTimerModal } from './components/TwoMinuteTimerModal';
import { NewHabitModal } from './components/NewHabitModal';
import { SystemSettingsModal, SystemSettings } from './components/SystemSettingsModal';
import { RankUpNotificationModal } from './components/RankUpNotificationModal';
import { systemAudio } from './utils/systemAudio';
import { usePWAInstall } from './utils/usePWAInstall';
import { calculateHunterRank, HunterRankInfo } from './utils/rankProgression';

export default function App() {
  const [settings, setSettings] = useState<SystemSettings>(() => {
    const saved = localStorage.getItem('sl_system_settings');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return {
      playerName: 'Jhondurd3n',
      soundEnabled: true,
      hapticsEnabled: true,
      autoPenaltyProtection: true,
    };
  });

  const [habits, setHabits] = useState<Habit[]>(() => {
    const saved = localStorage.getItem('sl_habits_zero_v1');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    // Also clean up old legacy key if it had non-zero past mock dates
    localStorage.removeItem('atomic_habits_data');
    return INITIAL_HABITS;
  });

  const [scorecard, setScorecard] = useState<ScorecardItem[]>(() => {
    const saved = localStorage.getItem('atomic_scorecard_data');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_SCORECARD;
  });

  const [selectedDate, setSelectedDate] = useState<string>(() => {
    return new Date().toISOString().split('T')[0];
  });

  const [activeTab, setActiveTab] = useState<'today' | 'stacks' | 'scorecard' | 'identity' | 'analysis'>('today');
  const [timerHabit, setTimerHabit] = useState<Habit | null>(null);
  const [isNewHabitModalOpen, setIsNewHabitModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);

  // Automated Rank Up Notification state
  const [rankUpData, setRankUpData] = useState<{ newRank: HunterRankInfo; previousRankTitle: string; level: number } | null>(null);

  const triggerRankUpEffects = (targetRank: HunterRankInfo, prevTitle: string, targetLvl: number) => {
    setRankUpData({
      newRank: targetRank,
      previousRankTitle: prevTitle,
      level: targetLvl,
    });
  };

  const { isInstallable, isOnline, install } = usePWAInstall();

  // Calculate total completed quests across all time
  const totalCompletedCount = habits.reduce(
    (sum, h) => sum + h.completedDates.length,
    0
  );

  const { currentRank, nextRank, level } = calculateHunterRank(totalCompletedCount);

  // Always dark theme
  useEffect(() => {
    document.documentElement.classList.add('dark');
    systemAudio.enabled = settings.soundEnabled;
  }, [settings.soundEnabled]);

  // Persist
  useEffect(() => {
    localStorage.setItem('sl_system_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('sl_habits_zero_v1', JSON.stringify(habits));
  }, [habits]);

  useEffect(() => {
    localStorage.setItem('atomic_scorecard_data', JSON.stringify(scorecard));
  }, [scorecard]);

  // Toggle habit with automated rank evaluation
  const handleToggleHabit = (habitId: string, date: string) => {
    const prevRankInfo = calculateHunterRank(totalCompletedCount);

    setHabits((prev) => {
      const nextHabits = prev.map((h) => {
        if (h.id !== habitId) return h;
        const isCompleted = h.completedDates.includes(date);
        const nextCompleted = isCompleted
          ? h.completedDates.filter((d) => d !== date)
          : [...h.completedDates, date];

        if (!isCompleted) {
          if (settings.soundEnabled) {
            systemAudio.playQuestComplete();
          }
          if (settings.hapticsEnabled && typeof navigator !== 'undefined' && navigator.vibrate) {
            navigator.vibrate([30, 20, 30]);
          }
        }

        return {
          ...h,
          completedDates: nextCompleted,
        };
      });

      // Calculate new rank with the updated habits
      const newTotal = nextHabits.reduce((sum, h) => sum + h.completedDates.length, 0);
      const newRankInfo = calculateHunterRank(newTotal);

      // Check if user ranked up
      if (newRankInfo.currentRank.minCompleted > prevRankInfo.currentRank.minCompleted) {
        triggerRankUpEffects(
          newRankInfo.currentRank,
          prevRankInfo.currentRank.rank,
          newRankInfo.level
        );
      }

      return nextHabits;
    });
  };

  const handleTabChange = (tab: typeof activeTab) => {
    setActiveTab(tab);
    if (settings.soundEnabled) {
      systemAudio.playSystemChime();
    }
  };

  const handleUpdateScorecardRating = (id: string, rating: 'positive' | 'neutral' | 'negative') => {
    setScorecard((prev) =>
      prev.map((item) => (item.id === id ? { ...item, rating } : item))
    );
    if (settings.soundEnabled) {
      systemAudio.playSystemChime();
    }
  };

  const handleAddScorecardItem = (
    routine: string,
    timeOfDay: TimeOfDay,
    rating: 'positive' | 'neutral' | 'negative'
  ) => {
    const newItem: ScorecardItem = {
      id: `sc-${Date.now()}`,
      routine,
      timeOfDay,
      rating,
    };
    setScorecard((prev) => [newItem, ...prev]);
    if (settings.soundEnabled) {
      systemAudio.playQuestComplete();
    }
  };

  const handleDeleteScorecardItem = (id: string) => {
    setScorecard((prev) => prev.filter((i) => i.id !== id));
  };

  const handleSaveHabit = (newHabit: Habit) => {
    setHabits((prev) => [newHabit, ...prev]);
    if (settings.soundEnabled) {
      systemAudio.playQuestComplete();
    }
  };

  const handleResetToday = () => {
    setHabits((prev) =>
      prev.map((h) => ({
        ...h,
        completedDates: h.completedDates.filter((d) => d !== selectedDate),
      }))
    );
  };

  const handleResetAllData = () => {
    localStorage.removeItem('sl_habits_zero_v1');
    localStorage.removeItem('atomic_habits_data');
    localStorage.removeItem('atomic_scorecard_data');
    setHabits(INITIAL_HABITS.map((h) => ({ ...h, completedDates: [] })));
    setScorecard(INITIAL_SCORECARD);
  };

  const handleExportData = () => {
    const data = {
      settings,
      habits,
      scorecard,
      exportTimestamp: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SoloLeveling_Save_${settings.playerName}_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const navItems = [
    { id: 'today', label: 'QUESTS', icon: CalendarCheck },
    { id: 'stacks', label: 'COMBOS', icon: Link2 },
    { id: 'scorecard', label: 'AUDIT', icon: ClipboardCheck },
    { id: 'identity', label: 'STATUS', icon: Award },
    { id: 'analysis', label: 'ARCHIVE', icon: BookOpen },
  ] as const;

  const renderTabContent = () => {
    switch (activeTab) {
      case 'today':
        return (
          <TodayHabitsView
            habits={habits}
            selectedDate={selectedDate}
            onSelectDate={setSelectedDate}
            onToggleHabit={handleToggleHabit}
            onOpenTwoMinuteModal={setTimerHabit}
            onOpenNewHabitModal={() => setIsNewHabitModalOpen(true)}
            creatorName={settings.playerName}
          />
        );
      case 'stacks':
        return (
          <HabitStackingView
            habits={habits}
            onOpenNewHabitModal={() => setIsNewHabitModalOpen(true)}
            onOpenTwoMinuteModal={setTimerHabit}
            creatorName={settings.playerName}
          />
        );
      case 'scorecard':
        return (
          <ScorecardView
            scorecard={scorecard}
            onUpdateRating={handleUpdateScorecardRating}
            onAddItem={handleAddScorecardItem}
            onDeleteItem={handleDeleteScorecardItem}
            creatorName={settings.playerName}
          />
        );
      case 'identity':
        return (
          <IdentityAnalyticsView
            habits={habits}
            identities={INITIAL_IDENTITIES}
            creatorName={settings.playerName}
            onPreviewRankUp={() => triggerRankUpEffects(nextRank || currentRank, currentRank.rank, level + 1)}
          />
        );
      case 'analysis':
        return <DeepAnalysisView creatorName={settings.playerName} />;
      default:
        return null;
    }
  };

  return (
    /* h-dvh and max-h-dvh with overflow-hidden ensures ZERO SCROLLING on the entire view */
    <div className="h-dvh max-h-dvh w-full bg-[#020617] text-slate-100 flex flex-col font-mono select-none overflow-hidden bg-system-grid relative">
      {/* 1. Solo Leveling Top Header Bar (Fixed height: h-10) */}
      <header className="h-10 shrink-0 z-40 bg-[#040915]/95 backdrop-blur-md border-b border-cyan-500/40 shadow-[0_0_15px_rgba(6,182,212,0.18)] flex items-center px-2.5 sm:px-4 justify-between gap-2">
        {/* Brand & Automated Rank Label */}
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="w-5 h-5 rounded bg-cyan-500 text-slate-950 flex items-center justify-center font-black text-[10px] shadow-[0_0_6px_#22d3ee]">
            S
          </span>
          <div className="flex items-baseline gap-1 whitespace-nowrap">
            <span className="text-[10px] font-black tracking-widest text-cyan-400">
              [SYSTEM]
            </span>
            <span className="text-[9px] text-stone-300">
              {settings.playerName.toUpperCase()}
            </span>
            {/* System Automated Rank Label (Interactive Rank FX trigger) */}
            <button
              type="button"
              onClick={() => triggerRankUpEffects(currentRank, 'HUNTER STATUS', level)}
              className={`text-[8px] px-1.5 py-0.2 rounded border font-black uppercase cursor-pointer hover:brightness-125 transition-all shadow-[0_0_6px_rgba(6,182,212,0.4)] ${currentRank.badgeColor}`}
              title="Click to trigger Rank Animation FX"
            >
              {currentRank.rank} ⚡
            </button>
          </div>
        </div>

        {/* Desktop Quick Nav Buttons */}
        <nav className="hidden sm:flex items-center gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleTabChange(item.id)}
                className={`px-2 py-0.5 text-[8px] font-bold rounded flex items-center gap-1 transition-all ${
                  isActive
                    ? 'bg-cyan-500 text-slate-950 shadow-[0_0_6px_#22d3ee]'
                    : 'text-stone-400 hover:text-cyan-300'
                }`}
              >
                <Icon className="w-2.5 h-2.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Quick Utilities */}
        <div className="flex items-center gap-1 shrink-0">
          {isInstallable && (
            <button
              onClick={install}
              className="px-1.5 py-0.5 rounded bg-cyan-950 border border-cyan-400 text-cyan-300 font-bold text-[8px] flex items-center gap-0.5 hover:bg-cyan-900"
              title="Install offline APK"
            >
              <Download className="w-2.5 h-2.5" />
              <span>APK</span>
            </button>
          )}

          <div className={`px-1 py-0.2 rounded text-[7px] font-bold flex items-center gap-0.5 ${
            isOnline ? 'text-cyan-400 bg-cyan-950/60 border border-cyan-500/40' : 'text-amber-400 bg-amber-950/60 border border-amber-500/40'
          }`}>
            {isOnline ? <Wifi className="w-2 h-2" /> : <WifiOff className="w-2 h-2" />}
            <span className="hidden sm:inline">{isOnline ? 'ONLINE' : 'OFFLINE'}</span>
          </div>

          <button
            onClick={() => setIsSettingsModalOpen(true)}
            className="w-6 h-6 rounded border border-cyan-500/40 bg-slate-950 flex items-center justify-center text-cyan-400 hover:text-white hover:border-cyan-300"
            aria-label="Settings"
            title="System Settings"
          >
            <Settings className="w-3 h-3" />
          </button>
        </div>
      </header>

      {/* 2. Main Full-Screen Area (Strictly Fits in Viewport, Zero Scrolling) */}
      <main className="flex-1 min-h-0 w-full max-w-4xl mx-auto p-1.5 sm:p-2 flex flex-col overflow-hidden">
        {renderTabContent()}
      </main>

      {/* 3. Bottom Mobile Command Bar (Fixed height: h-11) */}
      <nav className="sm:hidden h-11 shrink-0 z-40 bg-[#040915]/95 backdrop-blur-md border-t border-cyan-500/40 grid grid-cols-5 items-center px-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleTabChange(item.id)}
              className={`flex flex-col items-center justify-center min-h-[38px] transition-all ${
                isActive
                  ? 'text-cyan-300 font-bold drop-shadow-[0_0_6px_#22d3ee]'
                  : 'text-stone-500 hover:text-cyan-400'
              }`}
              aria-label={item.label}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
              <span className="text-[7px] tracking-tight mt-0.5 leading-none">
                {item.label}
              </span>
              {isActive && (
                <span className="w-1 h-1 rounded-full bg-cyan-400 mt-0.5 shadow-[0_0_4px_#22d3ee]" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Modals */}
      <TwoMinuteTimerModal
        habit={timerHabit}
        onClose={() => setTimerHabit(null)}
        onComplete={(id) => handleToggleHabit(id, selectedDate)}
      />

      <NewHabitModal
        isOpen={isNewHabitModalOpen}
        onClose={() => setIsNewHabitModalOpen(false)}
        onSaveHabit={handleSaveHabit}
      />

      <SystemSettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        settings={settings}
        onUpdateSettings={setSettings}
        totalCompletedCount={totalCompletedCount}
        onResetToday={handleResetToday}
        onResetAllData={handleResetAllData}
        onExportData={handleExportData}
        onTestRankUp={() => {
          setIsSettingsModalOpen(false);
          triggerRankUpEffects(
            nextRank || currentRank,
            currentRank.rank,
            level + 1
          );
        }}
      />

      <RankUpNotificationModal
        isOpen={!!rankUpData}
        onClose={() => setRankUpData(null)}
        newRank={rankUpData?.newRank ?? null}
        previousRankTitle={rankUpData?.previousRankTitle}
        level={rankUpData?.level ?? 1}
      />
    </div>
  );
}
