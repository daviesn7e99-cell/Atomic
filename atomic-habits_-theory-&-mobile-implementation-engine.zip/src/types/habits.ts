export type HabitCategory = 'health' | 'mind' | 'craft' | 'focus' | 'relationships';

export type TimeOfDay = 'morning' | 'afternoon' | 'evening';

export interface Habit {
  id: string;
  title: string;
  identityStatement: string; // "I am a runner", "I am a disciplined writer"
  anchorHabit: string; // The existing cue habit ("After I pour coffee")
  twoMinuteVersion: string; // Gateway version ("Open notebook to 1st page")
  temptationBundle?: string; // Optional reward bundling ("Listen to favorite podcast")
  timeOfDay: TimeOfDay;
  timeTarget?: string; // e.g. "07:30 AM"
  category: HabitCategory;
  frequency: 'daily' | 'weekdays' | 'custom';
  completedDates: string[]; // YYYY-MM-DD strings
  createdAt: string;
  notes?: string;
  targetCountPerDay?: number;
}

export interface ScorecardItem {
  id: string;
  routine: string;
  timeOfDay: TimeOfDay;
  rating: 'positive' | 'neutral' | 'negative';
  category?: string;
  note?: string;
}

export interface IdentityProfile {
  id: string;
  archetype: string;
  statement: string;
  color: string;
  associatedHabits: string[];
}

export interface HabitLogStats {
  totalCompleted: number;
  currentStreak: number;
  longestStreak: number;
  votesCasted: number;
  missedYesterday: boolean;
  complianceRate: number; // 0 to 100
}
